// import React, { useState } from 'react'
// import axios from 'axios';
// import { useDispatch } from 'react-redux';
// import './CreatePost.css';
// import { addPost } from './actions';
// import { Link } from 'react-router-dom';
// import Header from './Header';

// const CreatePost = () => {
//   const [title, setTitle] = useState("");
//   const [body, setBody] = useState("");
//   const [showCreatePostForm, setShowCreatePostForm] = useState(true);
//   const [response, setResponse] = useState({});
//   const dispatch = useDispatch();

//   const submitForm = async (e) => {
//     e.preventDefault();
//     try {
//       const res = await axios.post('https://jsonplaceholder.typicode.com/posts', {
//         title: title,
//         body: body,
//         userId: 150, 
//       });
//       setShowCreatePostForm(false);
//       setResponse(res.data);
//       console.log('Post created:', response);
//       setTitle('');
//       setBody('');
//       dispatch(addPost(res.data));
//     } catch (error) {
//       console.error('Error creating post:', error);
//     }

//   };

//   return (
//     <>
//     <Header />
//       <div className="container mt-4">
//         {
//           showCreatePostForm ?
//             <><h1 className="h1">Create a New Post</h1><form onSubmit={submitForm} className="container">

//               <div>
//                 <div className="mb-3">
//                   <label htmlFor="title" className="form-label">Title</label>
//                   <input type="text" className="form-control" id="title" name="title" autoComplete='off'
//                     value={title} onChange={(e) => setTitle(e.target.value)} />
//                 </div>
//                 <div className="mb-3">
//                   <label htmlFor="body" id="body" autoComplete="off"
//                     value={body}
//                     onChange={(e) => setBody(e.target.value)} className="form-label">Body</label>
//                   <textarea className="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
//                 </div>

//                 <button type="submit" className="btn btn-success">Create Post</button>
//               </div>

//             </form></> : <div>{response.title}{response.body}</div>
//         }
//       </ div>
//       <div>
//         <Link to="/viewMyBlogs">View my Blogs</Link>
//       </div>


//     </>
//   )
// }

// export default CreatePost



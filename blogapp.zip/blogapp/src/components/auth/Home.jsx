// import React, { useEffect, useState } from 'react'
// import { Link } from 'react-router-dom'
// import './Home.css'
// import LogoutButton from '../Logout'
// import AuthDetails from '../AuthDetails'
// import Header from '../Header'

// const Home = () => {
//   return (
// <>  
// <Header />

// </>

//   )
// }

// export default Home

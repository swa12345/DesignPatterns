// import React from 'react';
// import { getAuth, signOut } from 'firebase/auth';

// const Logout = () => {
//   const handleLogout = async () => {
//     try {
//       const auth = getAuth();
//       await signOut(auth);

//     } catch (error) {
//       console.error('Error occurred during logout:', error);
//     }
//   };

//   return (
//     <button onClick={handleLogout}>Logout</button>
//   );
// };

// export default Logout;

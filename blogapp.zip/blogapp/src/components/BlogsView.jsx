// import React from 'react'

// const BlogsView = ({data}) => {
//     console.log(data);
//   return (
//     <div>
//       {data}
//       {"hello"}
//     </div>
//   )
// }

// export default BlogsView

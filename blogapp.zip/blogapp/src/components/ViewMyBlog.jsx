// import React, { useState, useEffect } from 'react';
// import CreateBlog from './CreateBlog';
// import BlogsView from './BlogsView';
// import BlogList from './BlogList';
// import { Link } from 'react-router-dom';
// // import BlogLists from './BlogLists';


// const ViewMyBlog = () => {
//   const initialBlogs = JSON.parse(localStorage.getItem('blogs')) || [];
//   const [blogs, setBlogs] = useState(initialBlogs);
//   const [dataFromLocalStorage,setDataFromLocalStorage] = useState(null)

//   // Save the blog data to localStorage whenever the blogs state changes
//   useEffect(() => {
//     // localStorage.setItem('blogs', JSON.stringify(blogs));
//     localStorage.setItem('blogs', JSON.stringify(blogs));
//   }, [blogs]);

//   // Function to add a new blog to the state
//   const handleAddBlog = (newBlog) => {
//     setBlogs((prevBlogs) => [...prevBlogs, newBlog]);
//   };

//   // Function to delete a blog from the state
//   const handleDeleteBlog = (blogId) => {
//     setBlogs((prevBlogs) => prevBlogs.filter((blog) => blog.id !== blogId));
//   };

//   return (
//     <>
//     <div>
//       <CreateBlog onAddBlog={handleAddBlog} />
//       {/* <BlogsView data={dataFromLocalStorage} /> */}
      
//     </div>
//     <div>
//         <BlogList blogs={blogs} onDeleteBlog={handleDeleteBlog} />
//     </div>

//     <div>
//         {/* <BlogsView data={dataFromLocalStorage} /> */}
//         {/* <BlogsView data={dataFromLocalStorage} onDeleteBlog={handleDeleteBlog}/> */}
//     </div>
//     </>
//   );
// };

// export default ViewMyBlog;

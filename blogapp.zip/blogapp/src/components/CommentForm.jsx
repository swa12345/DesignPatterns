import React, { useState } from 'react';

const CommentForm = ({ onAddComment }) => {
  const [comment, setComment] = useState('');

  const handleCommentChange = (e) => {
    setComment(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Assuming a user object with a unique ID for simplicity
    const user = { id: 1, name: 'John Doe' };

    // Create a new comment object
    const newComment = {
      id: Date.now(), // Use a unique identifier (you can use a library like uuid)
      body: comment,
      name: user.name,
      email: 'john.doe@example.com',
    };

    // Call the callback function to add the new comment to the local state
    onAddComment(newComment);

    // Reset the comment input field after submission
    setComment('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <textarea
        rows="4"
        cols="50"
        value={comment}
        onChange={handleCommentChange}
        required
      />
      <br />
      <button type="submit">Submit Comment</button>
    </form>
  );
};

export default CommentForm;

// import React, { useState } from 'react'
// import axios from 'axios';
// import { useDispatch } from 'react-redux';
// import './CreatePost.css';
// import { addPost } from './actions';
// import { Link } from 'react-router-dom';
// import Header from './Header';

// const CreateBlog = ({ onAddBlog }) => {
//   const [title, setTitle] = useState("");
//   const [body, setBody] = useState("");

// //   const submitForm = async (e) => {
// //     e.preventDefault();
// //     try {
// //       const res = await axios.post('https://jsonplaceholder.typicode.com/posts', {
// //         title: title,
// //         body: body,
// //         userId: 150, 
// //       });
// //       setShowCreatePostForm(false);
// //       setResponse(res.data);
// //       console.log('Post created:', response);
// //       setTitle('');
// //       setBody('');
// //       dispatch(addPost(res.data));
// //     } catch (error) {
// //       console.error('Error creating post:', error);
// //     }

//     const submitForm = (e) => {
//         e.preventDefault();
    
//         // Assuming a user object with a unique ID for simplicity
//         const user = { id: 1, name: 'John Doe' };
    
//         // Create a new blog object
//         const newBlog = {
//           id: Date.now(), // Use a unique identifier (you can use a library like uuid)
//           title:title,
//           body:body,
//           date: new Date().toISOString(),
          
//         };
    
//         // Call the callback function to add the new blog to the state
//         onAddBlog(newBlog);
//         console.log(newBlog);
    
//         // Clear the form fields after submission
//         setTitle('');
//         setBody('');

//   };

//   return (
//     <>
//     <Header />
//       <div className="container mt-4">
//         {
//         //   showCreatePostForm ?
//             <><h1 className="h1">Create a New Post</h1><form onSubmit={submitForm} className="container">

//               <div>
//                 <div className="mb-3">
//                   <label htmlFor="title" className="form-label">Title</label>
//                   <input type="text" className="form-control" id="title" name="title" autoComplete='off'
//                     value={title} onChange={(e) => setTitle(e.target.value)} />
//                 </div>
//                 <div className="mb-3">
//                   <label htmlFor="body" id="body" autoComplete="off"

//                     className="form-label">Body</label>
//                   <textarea value={body}  onChange={(e1) => setBody(e1.target.value)} className="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
//                 </div>

//                 <button type="submit" className="btn btn-success">Create Post</button>
//               </div>

//             </form>
//             {/* <div>{title}</div>
//             <div>{body}</div> */}
//             </> 
            
//             // : <div>{response.title}{response.body}</div>
//         }
//       </ div>
//       {/* <div>
//         <Link to="/viewMyBlogs">View my Blogs</Link>
//       </div> */}


//     </>
//   )
// }

// export default CreateBlog;
import React, { useEffect, useState } from 'react';
import { dataRef } from '../firebase';
function CreateBlog(){
  const [name,setName]=useState('')
  const [allValue,setAllValue]=useState([])
  const handleAdd=()=>{
      if(name!==""){
      dataRef.ref().child("all").push(name)
      setName("")
      }
  }
  useEffect(()=>{
      dataRef.ref().child("all").on('value',data=>{
          const getData=Object.values(data.val())
          setAllValue(getData)
      }) 
  },[])
  console.log(allValue)
  return(
      <div>
          <input value={name} onChange={(e)=>{setName(e.target.value)}} />
          <button onClick={handleAdd}>Add</button>
          <div>
              {allValue.map((valData,i)=><h1 key={i}>{valData}</h1>)}
          </div>
      </div>
  );
}
export default CreateBlog;
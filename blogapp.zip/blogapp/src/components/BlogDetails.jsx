import React, { useEffect, useState } from 'react';
import { Link, Route, Router } from 'react-router-dom';
import './BlogDetails.css';
import CommentForm from './CommentForm';

const BlogDetails = () => { 
  const [blogDetails, setBlogDetails] = useState([]);
  const [userDetails, setUserDetails] = useState({ name: '', email: '', website: '' });
  // const [postComments, setPostComments] = useState({ name:'', body:'' });
  const [postComments, setPostComments] = useState([]);
  const searchParam = new URLSearchParams(window.location.search);
  const userId = searchParam.get('userId');
  const postId = searchParam.get('postId');
  console.log('*******************', searchParam.get('userId'));
  console.log('*******post1********', searchParam.get('postId'));


  useEffect(() => {
    fetch(`https://jsonplaceholder.typicode.com/users/${userId}/posts?id=${postId}`)
      .then(response => response.json())
      .then(data => console.log(setBlogDetails(data)))
      .catch(error => console.log(error));

    fetch(`https://jsonplaceholder.typicode.com/users/${userId}`)

      .then(response => response.json())
      .then(data => console.log(setUserDetails(data)))
      .catch(error => console.log(error));

    // fetch(`https://jsonplaceholder.typicode.com/posts/${postId}/comments`)
    //   .then(response => response.json())
    //   .then(data => console.log(setPostComments(data)))
    //   .catch(error => console.log(error));

      const storedComments = JSON.parse(localStorage.getItem(`comments_${postId}`) || '[]');
      setPostComments(storedComments);
  }, []);

  const handleAddComment = (newComment) => {
    // setPostComments((prevComments) => [...prevComments, newComment]);
    const updatedComments = [...postComments, newComment];
    localStorage.setItem(`comments_${postId}`, JSON.stringify(updatedComments));
    setPostComments(updatedComments);
  };

  return (
    <>
    <div className='container'>
      <h1>Blog Details</h1>
      {blogDetails.map(post => (
        <div key={post.id} className='details'>
          <p>{post.body}</p>

        </div>
      ))}
      
      <h3>Blog Created by</h3>
      <div className='details'>
        <p>{userDetails.name}</p>
        <p>{userDetails.email}</p>
        <p>References - {userDetails.website}</p>
      </div>

      <h3>Comments</h3>
      {postComments.map(comments => (
        <div key={comments.id} className='details'>
          <p>{comments.body}</p>
        </div>
        ))}


      {/* // <h3>Comments</h3>
      // <div className='details'>
      //   <p>{postComments.name}</p>
      //   <p>{postComments.body}</p>
      // </div> */}

      
      

    </div>

    <h2>Add a Comment</h2>
      <CommentForm onAddComment={handleAddComment} /> {/* Pass the onAddComment prop */}

    </>

  );
};

export default BlogDetails;
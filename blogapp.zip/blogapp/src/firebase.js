// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import firebase from 'firebase/compat/app';
import { getAuth } from "firebase/auth";
// import { getFirestore } from 'firebase/firestore';
import 'firebase/compat/database';

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC6soep1mRYEMOf9eaqfnQwPFB7jPHuDPc",
  authDomain: "blogapp-99fb5.firebaseapp.com",
  projectId: "blogapp-99fb5",
  storageBucket: "blogapp-99fb5.appspot.com",
  messagingSenderId: "782367711296",
  appId: "1:782367711296:web:018fb727886e0bd5a9bfa5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
// const db = getFirestore(app);

export const auth = getAuth(app);


export const dataRef=firebase.database();
export default app;










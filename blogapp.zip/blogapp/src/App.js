// import logo from './logo.svg';
// import './App.css';
// import SignIn from './components/auth/SignIn';
// import SignUp from './components/auth/SignUp';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import BlogLists from './components/BlogLists';
// import BlogDetails from './components/BlogDetails';
// import CreatePost from './components/CreatePost';
// import Home from './components/auth/Home';
// // import Homs from './components/Home';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import ViewMyBlogs from './components/ViewMyBlogs';
// import LogoutButton from './components/Logout'
// import AuthDetails from './components/AuthDetails';
// import ProtectedRoute from './components/auth/ProtectedRoute';
// import Header from './components/Header';
// import ProtectedRouteWrapper from './components/auth/ProtectedRoute';
// import { UserAuthContextProvider } from './Context/UserAuthContext';

import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col } from "react-bootstrap";
import { Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./components/Home";
import Login from "./components/Login";
import Signup from "./components/SignUp";
import ProtectedRoute from "./components/ProtectedRoute";
import { UserAuthContextProvider } from "./Context/UserAuthContext";
// import CreatePost from "./components/CreatePost";
import BlogLists from './components/BlogLists';
import BlogDetails from "./components/BlogDetails";
import CommentForm from "./components/CommentForm";
// import ViewMyBlogs from './components/ViewMyBlogs';
import CreateBlog from "./components/CreateBlog";
import ViewMyBlog from './components/ViewMyBlog';
import BlogList from './components/BlogList';
// import ViewBlog from './components/ViewBlog';
import BlogsView from './components/BlogsView';



function App() {
  // 
  
  // return (
  //   <BrowserRouter>
  //   <Router>
  //     {/* <Routes>
  //       <Route exact path="/" component={BlogList} />
  //       {/* <Route exact path="/my-posts" component={MyBlogPosts} />
  //       <Route exact path="/posts/:postId" component={BlogPost} /> */}
  //     {/* </Routes> */}
  //   {/* // </Router> */} */ 

  //   <Route path="/" exact component={BlogList} />
  //    {/* <Route path="/about" component={About} />
  //   <Route path="/contact" component={Contact} /> */}
  // </Router>
  // </BrowserRouter>
  // );

  // return (
  //   <Router>
  //     <Switch>
  //       <Route exact path="/" component={BlogLists} />
  //       {/* <Route exact path="/my-posts" component={MyBlogPosts} />
  //       <Route exact path="/posts/:postId" component={BlogPost} /> */}
  //     </Switch>
  //   </Router>
  // );

  // return (
  //   <>    
  //   <Router>
  //   <Routes>
  //       <Route exact path="/" element={<BlogLists />} />
  //       <Route path="/blogDetails" element={<BlogDetails />} />
  //       <Route path="/signIn" element={<SignIn />} />
  //       <Route path="/Home" element={<Home />} />
  //       <Route path="/signUp" element={<SignUp />} />
  //       <Route path="/createPost" element={<CreatePost />} />
  //       <Route path="/viewMyBlogs" element={<ViewMyBlogs />} />

  //       <Route path="/protected" component={ProtectedRouteWrapper} />


  //       {/* <Route path="/signUp" element={<SignUp />} /> */}
  //       {/* <Route path="/protected" component={<ProtectedRoute />} /> */}

  //       {/* <Route path="/signIn" element={<SignIn />} /> */}
  //       {/* <ProtectedRoute path="/Home" component={<Home />} /> */}

  //         {/* <Route path='/home' element={<ProtectedRoute />} /> */}
  //           {/* specify private routes here  */}
  //           {/* <Route path='/home' element={<Home />} /> */}
  //           {/* <Route path="/createPost" element={<CreatePost />} /> */}
  //           {/* <Route path="viewMyBlogs" element={<ViewMyBlogs />} /> */}
  //         {/* </Route> */}
          
  //       {/* <ProtectedRoute  path="/blogDetails" component={<BlogDetails/>} />
  //       <ProtectedRoute  path="/createPost" component={<CreatePost/>} />
  //       <ProtectedRoute  path="/viewMyBlogs" component={<viewMyBlogs/>} /> */}

  //       {/* <Route path="/Homs" element={<Homs />} /> */}
  //       {/* <Route path="/blogDetail" element={<Home} */}
  //       {/* <Route path="/my-posts" element={<MyBlogPosts />} /> */}
  //       {/* <Route path="/about" element={<About />} />
  //       <Route path="/contact" element={<Contact />} /> */}
  //       {/* Other protected routes */}

  //     </Routes>
  //   </Router>


  //   {/* <LogoutButton /> */}
  //   {/* <AuthDetails /> */}
  //   </>

  // )
  const postId = 1; 
  return (
    <>
    
    {/* <BlogDetails postId={postId} /> */}
    {/* <Container style={{ width: "400px" }}> */}
      <Row>
        <Col>
          <UserAuthContextProvider>
            <Routes>
              <Route
                path="/createMyBlogs"
                element={
                  <ProtectedRoute>
                    <Home />
                    {/* <CreatePost /> */}
                  </ProtectedRoute>
                }
              />
               {/* <Route
                path="/createPost"
                element={
                  <ProtectedRoute>
                    <CreatePost />
                  </ProtectedRoute>
                }
              /> */}
              <Route path="/" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/blogs" element={<BlogLists />} />
              <Route path="/comments" element = {<CommentForm/>} />
              <Route path="/blogDetails" element={<BlogDetails />} />
              {/* <Route path="/viewMyBlogs" element={<ViewMyBlogs />} /> */}

              <Route path="/createBlog" element={<ViewMyBlog />} />
              <Route path="/createMyBlogs" element={<ViewMyBlog />} />
              <Route path="/createMyBlogs/blogList" element={<BlogList/>} /> 
              {/* <Route path="/viewBlogss" element={<ViewBlog/>} /> */}
              <Route path="/blogView" element = {<BlogsView />} />
              
            </Routes>
          </UserAuthContextProvider>
        </Col>
      </Row>
    {/* </Container> */}
    </>
  );

      }
export default App;
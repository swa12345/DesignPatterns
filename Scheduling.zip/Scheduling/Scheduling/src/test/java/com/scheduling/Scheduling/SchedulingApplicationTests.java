package com.scheduling.Scheduling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulingApplicationTests {

	@Test
	void contextLoads() {
	}

}

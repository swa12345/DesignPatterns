package com.citiustech.scheduling.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Notes {
	@Id
	private int notes_id;
	private int patient_id;
	private int physician_id;
	private int nurse_id;
	private int appointment_id;	
	private String message_description;
	private String urgency_level;
	private String message_from;
	private String message_to;
	private String reply_from;
	private String reply_to;
	private LocalDate create_date;

	public Notes() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Notes(int notes_id, int patient_id, int physician_id, int nurse_id, int appointment_id,
			String message_description, String urgency_level, String message_from, String message_to, String reply_from,
			String reply_to, LocalDate create_date) {
		super();
		this.notes_id = notes_id;
		this.patient_id = patient_id;
		this.physician_id = physician_id;
		this.nurse_id = nurse_id;
		this.appointment_id = appointment_id;
		this.message_description = message_description;
		this.urgency_level = urgency_level;
		this.message_from = message_from;
		this.message_to = message_to;
		this.reply_from = reply_from;
		this.reply_to = reply_to;
		this.create_date = create_date;
	}

	public int getNotes_id() {
		return notes_id;
	}

	public void setNotes_id(int notes_id) {
		this.notes_id = notes_id;
	}

	public int getPatient_id() {
		return patient_id;
	}

	public void setPatient_id(int patient_id) {
		this.patient_id = patient_id;
	}

	public int getPhysician_id() {
		return physician_id;
	}

	public void setPhysician_id(int physician_id) {
		this.physician_id = physician_id;
	}

	public int getNurse_id() {
		return nurse_id;
	}

	public void setNurse_id(int nurse_id) {
		this.nurse_id = nurse_id;
	}

	public int getAppointment_id() {
		return appointment_id;
	}

	public void setAppointment_id(int appointment_id) {
		this.appointment_id = appointment_id;
	}

	public String getMessage_description() {
		return message_description;
	}

	public void setMessage_description(String message_description) {
		this.message_description = message_description;
	}

	public String getUrgency_level() {
		return urgency_level;
	}

	public void setUrgency_level(String urgency_level) {
		this.urgency_level = urgency_level;
	}

	public String getMessage_from() {
		return message_from;
	}

	public void setMessage_from(String message_from) {
		this.message_from = message_from;
	}

	public String getMessage_to() {
		return message_to;
	}

	public void setMessage_to(String message_to) {
		this.message_to = message_to;
	}

	public String getReply_from() {
		return reply_from;
	}

	public void setReply_from(String reply_from) {
		this.reply_from = reply_from;
	}

	public String getReply_to() {
		return reply_to;
	}

	public void setReply_to(String reply_to) {
		this.reply_to = reply_to;
	}

	public LocalDate getCreate_date() {
		return create_date;
	}

	public void setCreate_date(LocalDate create_date) {
		this.create_date = create_date;
	}

	@Override
	public String toString() {
		return "Notes [notes_id=" + notes_id + ", patient_id=" + patient_id + ", physician_id=" + physician_id
				+ ", nurse_id=" + nurse_id + ", appointment_id=" + appointment_id + ", message_description="
				+ message_description + ", urgency_level=" + urgency_level + ", message_from=" + message_from
				+ ", message_to=" + message_to + ", reply_from=" + reply_from + ", reply_to=" + reply_to
				+ ", create_date=" + create_date + "]";
	}

}

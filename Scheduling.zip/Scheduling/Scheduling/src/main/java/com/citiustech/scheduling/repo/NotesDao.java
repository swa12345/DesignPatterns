package com.citiustech.scheduling.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citiustech.scheduling.entity.Notes;

public interface NotesDao extends JpaRepository<Notes, Integer> {
	
}


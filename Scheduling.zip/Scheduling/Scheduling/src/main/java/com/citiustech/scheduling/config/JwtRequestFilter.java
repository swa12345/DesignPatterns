package com.citiustech.scheduling.config;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.HttpClientErrorException.Unauthorized;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import com.citiustech.scheduling.entity.CustomUserDetails;

//import lombok.extern.slf4j.Slf4j;

//@Slf4j
@Component
public class JwtRequestFilter extends OncePerRequestFilter {

	@Autowired
	RestTemplate restTemplate;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {

		final String requestTokenHeader = request.getHeader("Authorization");
		String jwtToken = null;
		if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
			jwtToken = requestTokenHeader.substring(7);

			try {
				HttpHeaders headers = new HttpHeaders();
				headers.set("Authorization", requestTokenHeader);
				HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

				CustomUserDetails customUserDetails = restTemplate.exchange("http://AuthenticationService" + "/authenticate",
						HttpMethod.GET, requestEntity, CustomUserDetails.class).getBody();

				if (!ObjectUtils.isEmpty(customUserDetails)) {
					response.setHeader("Authorization", "Bearer " + jwtToken);
					if (SecurityContextHolder.getContext().getAuthentication() == null) {
						SecurityContextHolder.getContext()
								.setAuthentication(new UsernamePasswordAuthenticationToken(customUserDetails.getPrincipal(),
										null, Arrays.asList(new SimpleGrantedAuthority(customUserDetails.getRole()))));
					}
					chain.doFilter(request, response);
				}
			} catch (Unauthorized ex) {
//				log.error(ex.getMessage());
				SecurityContextHolder.clearContext();
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
			}
		} else {
			SecurityContextHolder.clearContext();
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
		}
	}

}

package com.citiustech.scheduling.service;

import java.util.List;

import com.citiustech.scheduling.entity.Notes;

public interface NotesService {
	public List<Notes> getNotes();
	public Notes addNotes(Notes notes);
	public Notes updateNotes(Notes notes);
	public void deleteNotes(int notes_id);

}

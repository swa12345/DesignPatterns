package com.citiustech.scheduling.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int id;
	private String title;
	private String appointmentStatus;
	private String appointmentDescription;
	@Column(name = "appointmentDate")
	private LocalDate date;
	private String startTime;
	private String endTime;
	private int physicianId;
	private int patientId;
	private LocalDate modifiedDate;
	private int modifiedUser;
	private String reason;
	
	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Appointment(int id, String title, String appointmentStatus, String appointmentDescription, LocalDate date,
			String startTime, String endTime, int physicianId, int patientId, LocalDate modifiedDate,
			int modifiedUser, String reason) {
		super();
		this.id = id;
		this.title = title;
		this.appointmentStatus = appointmentStatus;
		this.appointmentDescription = appointmentDescription;
		this.date = date;
		this.startTime = startTime;
		this.endTime = endTime;
		this.physicianId = physicianId;
		this.patientId = patientId;
		this.modifiedDate = modifiedDate;
		this.modifiedUser = modifiedUser;
		this.reason = reason;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAppointmentStatus() {
		return appointmentStatus;
	}

	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}

	public String getAppointmentDescription() {
		return appointmentDescription;
	}

	public void setAppointmentDescription(String appointmentDescription) {
		this.appointmentDescription = appointmentDescription;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public int getPhysicianId() {
		return physicianId;
	}

	public void setPhysicianId(int physicianId) {
		this.physicianId = physicianId;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public LocalDate getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(LocalDate modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(int modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", title=" + title + ", appointmentStatus=" + appointmentStatus
				+ ", appointmentDescription=" + appointmentDescription + ", date=" + date + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", physicianId=" + physicianId + ", patientId=" + patientId
				+ ", modifiedDate=" + modifiedDate + ", modifiedUser=" + modifiedUser + ", reason=" + reason + "]";
	}
	
}

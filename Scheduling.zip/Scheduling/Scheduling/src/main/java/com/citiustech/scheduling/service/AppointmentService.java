package com.citiustech.scheduling.service;

import java.util.List;

import com.citiustech.scheduling.entity.Appointment;

public interface AppointmentService {
	
	public List<Appointment> getAppointments();
	public List<Appointment> getAppointmentsById(int id);
	public Appointment addAppointment(Appointment appointment);
	public Appointment updateAppointment(Appointment appointment);
	public void deleteAppointment(int id);
	
}

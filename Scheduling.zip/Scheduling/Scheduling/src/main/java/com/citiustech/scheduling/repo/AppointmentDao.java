package com.citiustech.scheduling.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.citiustech.scheduling.entity.Appointment;

public interface AppointmentDao extends JpaRepository<Appointment, Integer> {
	@Query("select a from Appointment a where a.physicianId=:physicianId ")
	List<Appointment> findByPhysicianId(@Param("physicianId") int id);
}

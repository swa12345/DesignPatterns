package com.citiustech.scheduling.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.scheduling.entity.Appointment;
import com.citiustech.scheduling.entity.Notes;
import com.citiustech.scheduling.service.AppointmentService;
import com.citiustech.scheduling.service.NotesService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
public class SchedulingController {
	@Autowired
	private AppointmentService appointmentService;
	
	@GetMapping("/view-appointments")
	@ApiOperation(value = "To Re	ceive all appointments")
	public List<Appointment> getAppointments() {
		return appointmentService.getAppointments();
	}
	
	@GetMapping("/view-appointments/{id}")
	@ApiOperation(value = "To Receive all appointments")
	public List<Appointment> getAppointments(@PathVariable ("id") int id) {
		System.out.println(id + "this is id");
		return appointmentService.getAppointmentsById(id);
	}
	
	@PostMapping("/add-appointment")
	@ApiOperation(value = "To add an appointment")
	public Appointment addAppointment(@RequestBody Appointment appointment) {
		return appointmentService.addAppointment(appointment);
	}
		
	@PutMapping("/update-appointment")
	@ApiOperation(value = "To update an appointment")
	public Appointment updateAppointment(@RequestBody Appointment appointment) {
		return appointmentService.updateAppointment(appointment);
	}
	
	@DeleteMapping("/delete-appointment/{id}")
	@ApiOperation(value = "To delete an appointment by id")
	public ResponseEntity<HttpStatus> deleteAppointment(@PathVariable int id) {
		try {
			this.appointmentService.deleteAppointment(id);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
//--------------------NotesController-----------------------------
	
	
	@Autowired
	private NotesService notesService;

	@GetMapping("/view-notes")
	@ApiOperation(value = "To receive all the notes")
	public List<Notes> getNotes() {
		return notesService.getNotes();
	}
	
	@PostMapping("/add-note")
	@ApiOperation(value = "To add a note")
	public Notes addNotes(@RequestBody Notes note) {
		return notesService.addNotes(note);
	}
		
	@PutMapping("/update-note")
	@ApiOperation(value = "To update a note")
	public Notes updateNotes(@RequestBody Notes note) {
		return notesService.updateNotes(note);
	}
	
	//update by ID
	// view notes by ID
	//view sent notes- history
	
	@DeleteMapping("/delete-note/{id}")
	@ApiOperation(value = "To delte a note by id")
	public ResponseEntity<HttpStatus> deleteNotes(@PathVariable int notesId) {
		try {
			this.notesService.deleteNotes(notesId);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}

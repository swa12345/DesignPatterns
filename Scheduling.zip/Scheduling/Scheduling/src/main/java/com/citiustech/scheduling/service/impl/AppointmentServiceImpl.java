package com.citiustech.scheduling.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.scheduling.entity.Appointment;
import com.citiustech.scheduling.repo.AppointmentDao;
import com.citiustech.scheduling.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService{
	@Autowired
	AppointmentDao appointmentDao;

	// get all appointments
	@Override
	public List<Appointment> getAppointments() {
		
		return appointmentDao.findAll();
	}

	// add appointment
	@Override
	public Appointment addAppointment(Appointment appointment) {
		appointmentDao.save(appointment);
		
		return appointment;
	}

	// update appointment
	@Override
	public Appointment updateAppointment(Appointment appointment) {
		appointmentDao.save(appointment);
		
		return appointment;
	}

	// delete appointment
	@Override
	public void deleteAppointment(int id) {
		appointmentDao.deleteById(id);
	}

	@Override
	public List<Appointment> getAppointmentsById(int physicianId) {
		
		return appointmentDao.findByPhysicianId(physicianId);
	}

}

package com.citiustech.scheduling.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.scheduling.entity.Notes;
import com.citiustech.scheduling.repo.NotesDao;
import com.citiustech.scheduling.service.NotesService;

@Service
public class NotesServiceImpl implements NotesService {

	@Autowired
	NotesDao notesDao;

	// get all Notes
	@Override
	public List<Notes> getNotes() {

		return notesDao.findAll();
	}

	// add notes
	@Override
	public Notes addNotes(Notes notes) {
		notesDao.save(notes);

		return notes;
	}

	// update notes
	@Override
	public Notes updateNotes(Notes notes) {
		notesDao.save(notes);

		return notes;
	}

	// delete Notes
	@Override
	public void deleteNotes(int notes_id) {
		notesDao.deleteById(notes_id);
	}

}

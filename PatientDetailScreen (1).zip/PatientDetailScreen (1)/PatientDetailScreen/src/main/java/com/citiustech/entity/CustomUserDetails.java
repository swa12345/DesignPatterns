package com.citiustech.entity;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class CustomUserDetails implements Serializable {


	private static final long serialVersionUID = 1L;

	Object principal;
	
	Object credentials;
	
	String role;

	public Object getPrincipal() {
		return principal;
	}

	public void setPrincipal(Object principal) {
		this.principal = principal;
	}

	public Object getCredentials() {
		return credentials;
	}

	public void setCredentials(Object credentials) {
		this.credentials = credentials;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public CustomUserDetails(Object principal, Object credentials, String role) {
		super();
		this.principal = principal;
		this.credentials = credentials;
		this.role = role;
	}

	public CustomUserDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}

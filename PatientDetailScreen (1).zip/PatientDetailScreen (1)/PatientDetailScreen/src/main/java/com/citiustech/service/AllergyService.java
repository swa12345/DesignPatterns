package com.citiustech.service;

import java.util.List;

import com.citiustech.dto.AllergyDTO;

public interface AllergyService {

	public List<AllergyDTO> getAllAllergyDetails();

	public AllergyDTO getAllergyById(String aId);

	public List<AllergyDTO> getAllergyByType(String aType);

	public List<String> getAllAllergiesType();

	public List<String> getAllAllergiesNames(String aType);

	public List<String> getAllergySourceByTypeAndName(String type, String name);

	public List<String> getAllergyIsoformByTypeAndNameAndDescription(String type, String name, String allergen);

	public List<String> getAllergyIdByTypeAndNameAndSourceAndIsoform(String type, String name, String allergen,
			String isoform);

}

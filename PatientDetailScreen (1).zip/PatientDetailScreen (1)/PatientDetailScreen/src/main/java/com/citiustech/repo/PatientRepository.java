package com.citiustech.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.citiustech.entity.Patient;

@Repository
public interface PatientRepository extends CrudRepository<Patient, Integer>{

	
}

package com.citiustech.entity;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Allergy_Details")
public class Allergy {

	@Id
	private String allergyId;
	
	private String allergyType; 
	
	private String allergyName; 
	
	private String allergySource;
	
	private String isoformsOrPartialSequencesOfAllergen;

	private String allerginicity;

	@Override
	public String toString() {
		return "Allergy [allergyId=" + allergyId + ", allergyType=" + allergyType + ", allergyName=" + allergyName
				+ ", allergySource=" + allergySource + ", isoformsOrPartialSequencesOfAllergen="
				+ isoformsOrPartialSequencesOfAllergen + ", allerginicity=" + allerginicity + "]";
	}

	public String getAllergyId() {
		return allergyId;
	}

	public void setAllergyId(String allergyId) {
		this.allergyId = allergyId;
	}

	public String getAllergyType() {
		return allergyType;
	}

	public void setAllergyType(String allergyType) {
		this.allergyType = allergyType;
	}

	public String getAllergyName() {
		return allergyName;
	}

	public void setAllergyName(String allergyName) {
		this.allergyName = allergyName;
	}

	public String getAllergySource() {
		return allergySource;
	}

	public void setAllergySource(String allergySource) {
		this.allergySource = allergySource;
	}

	public String getIsoformsOrPartialSequencesOfAllergen() {
		return isoformsOrPartialSequencesOfAllergen;
	}

	public void setIsoformsOrPartialSequencesOfAllergen(String isoformsOrPartialSequencesOfAllergen) {
		this.isoformsOrPartialSequencesOfAllergen = isoformsOrPartialSequencesOfAllergen;
	}

	public String getAllerginicity() {
		return allerginicity;
	}

	public void setAllerginicity(String allerginicity) {
		this.allerginicity = allerginicity;
	}

	public Allergy(String allergyId, String allergyType, String allergyName, String allergySource,
			String isoformsOrPartialSequencesOfAllergen, String allerginicity) {
		super();
		this.allergyId = allergyId;
		this.allergyType = allergyType;
		this.allergyName = allergyName;
		this.allergySource = allergySource;
		this.isoformsOrPartialSequencesOfAllergen = isoformsOrPartialSequencesOfAllergen;
		this.allerginicity = allerginicity;
	}

	public Allergy() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

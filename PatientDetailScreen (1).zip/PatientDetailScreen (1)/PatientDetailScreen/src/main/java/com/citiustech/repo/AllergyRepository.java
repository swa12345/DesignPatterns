package com.citiustech.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.citiustech.entity.Allergy;

@Repository
public interface AllergyRepository extends CrudRepository<Allergy, String> {

	List<Allergy> findByAllergyType(String allergyType);

	@Query("SELECT DISTINCT allergyType FROM Allergy")
	List<String> getDistinctAllergyType();

	@Query("Select distinct allergyName From Allergy a where a.allergyType in :allergiesType ")
	List<String> getDistinctAllergyNames(String allergiesType);
	

//	@Query("Select distinct allergyName From Allergy a where a.allergyType = :allergiesType ")
//	List<String> getDistinctAllergyNames(@Param(value = "allergiesType") String allergiesType);

	@Query("Select distinct allergySource From Allergy a where a.allergyType =?1  and a.allergyName =?2 ")
	List<String> getDistinctAllergySource(String allergiesType, String allergiesName);

	@Query("Select  isoformsOrPartialSequencesOfAllergen From Allergy a where a.allergyType  =?1 and a.allergyName  =?2 and a.allergySource  =?3 ")
	List<String> getDistinctAllergyIsoform(String allergiesType, String allergiesName, String allergensource);

	@Query("Select allergyId From Allergy a where a.allergyType  =?1 and a.allergyName  =?2 and a.allergySource  =?3 and a.isoformsOrPartialSequencesOfAllergen  =?4")
	List<String> getDistinctAllergyId(String allergiesType, String allergiesName, String allergensource,
			String isoform);

}

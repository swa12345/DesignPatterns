package com.citiustech.filter;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.access.channel.ChannelProcessingFilter;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.HttpClientErrorException.Unauthorized;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import com.citiustech.config.CorsFilter;
import com.citiustech.entity.CustomUserDetails;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

	@Autowired
	RestTemplate restTemplate;

	
	@Autowired
    private CorsFilter corsFilter;



   protected void configure(HttpSecurity http) throws Exception {
       http.csrf().disable()
        .addFilterBefore(corsFilter, ChannelProcessingFilter.class);
   }
   
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {

		final String requestTokenHeader = request.getHeader("Authorization");
		String jwtToken = null;
		if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
			jwtToken = requestTokenHeader.substring(7);

			try {
				HttpHeaders headers = new HttpHeaders();
				headers.set("Authorization", requestTokenHeader);
				HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

				CustomUserDetails customUserDetails = restTemplate.exchange("http://AuthenticationService" + "/authenticate",
						HttpMethod.GET, requestEntity, CustomUserDetails.class).getBody();

				if (!ObjectUtils.isEmpty(customUserDetails)) {
					response.setHeader("Authorization", "Bearer " + jwtToken);
					if (SecurityContextHolder.getContext().getAuthentication() == null) {
						SecurityContextHolder.getContext()
								.setAuthentication(new UsernamePasswordAuthenticationToken(customUserDetails.getPrincipal(),
										null, Arrays.asList(new SimpleGrantedAuthority(customUserDetails.getRole()))));
					}
					chain.doFilter(request, response);
				}
			} catch (Unauthorized ex) {
//				log.error(ex.getMessage());
				SecurityContextHolder.clearContext();
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
			}
		} else {
			SecurityContextHolder.clearContext();
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
		}
	}

}

package com.citiustech.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.dto.AllergyDTO;
import com.citiustech.service.AllergyService;


@RestController
@RequestMapping(value = "/api")
@CrossOrigin(origins = "http://localhost:4200")
public class AllergyController {

	@Autowired
	private AllergyService allergyService;

	@GetMapping(value = "/allergy")
	public ResponseEntity<List<AllergyDTO>> getAllAllergy() {

		List<AllergyDTO> allergylist = allergyService.getAllAllergyDetails();
		return new ResponseEntity<List<AllergyDTO>>(allergylist, HttpStatus.OK);
		
	}

	@GetMapping(value = "/allergy/{id}")
	public ResponseEntity<AllergyDTO> getAllergyById(@PathVariable("id") String aId) {
		AllergyDTO allergyDTO = allergyService.getAllergyById(aId);
		return new ResponseEntity<AllergyDTO>(allergyDTO, HttpStatus.OK);
	}

	@GetMapping(value = "/allergy/type/{type}")
	public ResponseEntity<List<AllergyDTO>> getAllergyByType(@PathVariable("type") String aType) {
		List<AllergyDTO> allergyDTOs = allergyService.getAllergyByType(aType);
		return new ResponseEntity<List<AllergyDTO>>(allergyDTOs, HttpStatus.OK);
	}

	@GetMapping(value = "/allergy/type")
	public ResponseEntity<List<String>> getAllAllergiesType() {
		List<String> allergytypes = allergyService.getAllAllergiesType();
		System.out.println(allergytypes);
		return new ResponseEntity<List<String>>(allergytypes, HttpStatus.OK);
	}

	@GetMapping(value = "/allergy/names/{type}")
	public ResponseEntity<List<String>> getAllAllergiesNames(@PathVariable("type") String aType) {
		List<String> allergyNames = allergyService.getAllAllergiesNames(aType);
		return new ResponseEntity<List<String>>(allergyNames, HttpStatus.OK);
	}

	@GetMapping("/allergy/{type}/{name}")
	public ResponseEntity<List<String>> getAllergySourceByTypeAndName(@PathVariable String type,
			@PathVariable String name) {
		List<String> allergySource = allergyService.getAllergySourceByTypeAndName(type, name);
		return new ResponseEntity<List<String>>(allergySource, HttpStatus.OK);
	}

	@GetMapping("/allergy/{type}/{name}/{allergen}")
	public ResponseEntity<List<String>> getAllergyIsoformByTypeAndNameAndDescription(@PathVariable String type,
			@PathVariable String name, @PathVariable String allergen) {
		List<String> allergyIsoform = allergyService.getAllergyIsoformByTypeAndNameAndDescription(type, name, allergen);
		return new ResponseEntity<List<String>>(allergyIsoform, HttpStatus.OK);
	}

	@GetMapping("/allergy/{type}/{name}/{allergen}/{isoform}")
	public ResponseEntity<List<String>> getAllergyIdByTypeAndNameAndDescriptionAndIsoform(@PathVariable String type,
			@PathVariable String name, @PathVariable String allergen, @PathVariable String isoform) {
		List<String> allergyId = allergyService.getAllergyIdByTypeAndNameAndSourceAndIsoform(type, name, allergen,
				isoform);

		return new ResponseEntity<List<String>>(allergyId, HttpStatus.OK);
	}
}

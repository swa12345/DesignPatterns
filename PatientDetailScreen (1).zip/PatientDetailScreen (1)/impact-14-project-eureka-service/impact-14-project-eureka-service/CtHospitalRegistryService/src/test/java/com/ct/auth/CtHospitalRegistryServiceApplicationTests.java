package com.ct.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CtHospitalRegistryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

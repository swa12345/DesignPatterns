package com.citiustech.email.service.impl;

import java.util.Locale;
import java.util.Set;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.citiustech.email.entity.EmailInfo;
import com.citiustech.email.entity.Template;
import com.citiustech.email.service.EmailSender;
import com.citiustech.email.service.EmailService;

@Service
public class EmailServiceImpl implements EmailService {

	private static final String PREFIX = "mail/";
	private static final String DEFAULT_LANGUAGE = "en";

	@Autowired
	private EmailSender emailSender;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private SpringTemplateEngine templateEngine;

	/***
	 * Send email based on the {@link Template}
	 * 
	 * @param template
	 * @param emailInfo
	 * @throws MessagingException 
	 * @throws MailException 
	 */
	@Override
	public void sendEmail(Template template, EmailInfo emailInfo) throws MailException, MessagingException {
		String htmlMessage = null;
		String subject = null;
		Locale locale = new Locale(DEFAULT_LANGUAGE);
		
		Context context = new Context(locale);
		context.setVariables(emailInfo.getPayload());
		Set<String> emailIds = emailInfo.getRecipient();

		htmlMessage = getTemplateContent(template, context);
		subject = getEmailSubject(template, locale);
		emailSender.sendEmail(htmlMessage, emailIds, subject, template);

	}

	/**
	 * Get email content
	 * 
	 * @param template
	 * @param context
	 */
	private String getTemplateContent(Template template, Context context) {
		return templateEngine.process(PREFIX + template.getTemplateName(), context);
	}

	/**
	 * Email subject
	 * 
	 * @param template
	 * @param locale
	 */
	private String getEmailSubject(Template template, Locale locale) {
		return messageSource.getMessage(template.getTemplateSubject(), null, locale);
	}

}

package com.citiustech.email.service;

import java.util.Set;

import javax.mail.MessagingException;

import org.springframework.mail.MailException;

import com.citiustech.email.entity.Template;

public interface EmailSender {

	void sendEmail(String htmlMessage, Set<String> reciepientEmails, String subject,
			Template template) throws MailException, MessagingException;
}

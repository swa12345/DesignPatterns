package com.citiustech.email.entity;

public enum Template {

	USER_ACTIVATION {

		@Override
		public String getTemplateName() {
			return "activation.html";
		}

		@Override
		public String getTemplateSubject() {
			return "email.activation.title";
		}

	},

	FORGOT_PASSWORD {

		@Override
		public String getTemplateName() {
			return "forgot_password_inline.html";
		}

		@Override
		public String getTemplateSubject() {
			return "email.forgotpassword.title";
		}

	};

	/***
	 * Get template name
	 */
	public abstract String getTemplateName();

	/**
	 * Get email subject
	 */
	public abstract String getTemplateSubject();


}

package com.citiustech.email.config;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.citiustech.email.util.EmailUtil;

@Configuration
public class EmailConfig {
	
	@Autowired
	private EmailUtil emailUtil;

	@Bean
	public JavaMailSender getJavaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

		mailSender.setHost(emailUtil.getSmtpHost());
		mailSender.setPort(Integer.parseInt(emailUtil.getSmtpPort()));
		mailSender.setUsername(emailUtil.getSmtpUserName());
		mailSender.setPassword(emailUtil.getSmtpPassword());

		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.debug", "true");

		return mailSender;
	}
    
}

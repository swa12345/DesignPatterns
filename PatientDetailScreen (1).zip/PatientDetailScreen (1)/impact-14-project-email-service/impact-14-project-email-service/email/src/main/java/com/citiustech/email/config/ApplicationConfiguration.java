package com.citiustech.email.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.citiustech.email.util.EmailUtil;

@Configuration
public class ApplicationConfiguration {

	@Bean
	public EmailUtil emailUtil() {
		return new EmailUtil();
	}

}

package com.citiustech.email.service;

import javax.mail.MessagingException;

import org.springframework.mail.MailException;

import com.citiustech.email.entity.EmailInfo;
import com.citiustech.email.entity.Template;

public interface EmailService {
	
	public void sendEmail(Template template, EmailInfo emailInfo) throws MailException, MessagingException;

}

package com.citiustech.email.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.email.entity.EmailResponse;
import com.citiustech.email.repo.EmailResponseRepository;
import com.citiustech.email.service.EmailResponseService;

@Service
public class EmailResponseServiceImpl implements EmailResponseService {

	@Autowired
	private EmailResponseRepository emailResponseRepository;

	public void save(EmailResponse emailResponse) {
		emailResponseRepository.save(emailResponse);
	}

}

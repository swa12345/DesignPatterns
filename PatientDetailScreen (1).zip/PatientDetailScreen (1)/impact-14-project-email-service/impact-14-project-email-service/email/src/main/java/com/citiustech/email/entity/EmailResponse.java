package com.citiustech.email.entity;

import java.time.LocalDateTime;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Entity
@Table(name = "Email_Response")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EmailResponse {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	int responseId;

	@Column(name = "Sender")
	String sender;

	@ElementCollection
	@CollectionTable(name = "Email_Response_Recipient", joinColumns = @JoinColumn(name = "Email_Response_ID"))
	@Column(name = "Recipient")
	Set<String> recipient;

	@Column(name = "Template_Name")
	String emailType;

	@Column(name = "Sent_Time")
	LocalDateTime sentTime;

	@Column(name = "Error_Message")
	String errorMessage;

}

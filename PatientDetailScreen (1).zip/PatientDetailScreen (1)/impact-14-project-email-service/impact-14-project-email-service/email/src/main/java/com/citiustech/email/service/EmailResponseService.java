package com.citiustech.email.service;

import com.citiustech.email.entity.EmailResponse;

public interface EmailResponseService {

	public void save(EmailResponse emailResponse);

}

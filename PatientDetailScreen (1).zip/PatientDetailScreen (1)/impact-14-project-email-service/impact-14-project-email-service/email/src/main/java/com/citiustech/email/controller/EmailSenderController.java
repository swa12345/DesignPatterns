package com.citiustech.email.controller;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.email.entity.EmailInfo;
import com.citiustech.email.entity.Template;
import com.citiustech.email.service.EmailService;

@RestController
@RequestMapping("/api/email")
public class EmailSenderController {

	@Autowired
	private EmailService emailService;

	/***
	 * Send email
	 * 
	 * @param notificationId
	 * @param payload
	 * @throws MessagingException
	 * @throws MailException
	 */
	@PreAuthorize("hasRole('PHY')")
	@PostMapping("/{notificationId}")
	public ResponseEntity<String> sendEmail(@PathVariable("notificationId") String notificationId,
			@RequestBody EmailInfo emailInfo) throws MailException, MessagingException {
		emailService.sendEmail(Template.valueOf(notificationId), emailInfo);
		return ResponseEntity.ok().body("Mail Sent successfully");
	}

}

package com.citiustech.email.util;

import org.springframework.beans.factory.annotation.Value;
import org.thymeleaf.util.StringUtils;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE)
@Getter
public class EmailUtil {

	private static final String EMAIL_PATTERN = "[a-z0-9._*%+-]+@[a-z0-9.-]+\\.[a-z0-9-]{2,}$";

	@Value("${spring.mail.username}")
	String smtpUserName;

	@Value("${spring.mail.password}")
	String smtpPassword;

	@Value("${spring.mail.host}")
	String smtpHost;

	@Value("${spring.mail.port}")
	String smtpPort;

	public static boolean isValidEmail(final String email) {
		return !StringUtils.isEmpty(email) && email.matches(EMAIL_PATTERN);
	}

}

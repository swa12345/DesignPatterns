package com.citiustech.email.service.impl;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Set;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.citiustech.email.entity.EmailResponse;
import com.citiustech.email.entity.Template;
import com.citiustech.email.service.EmailResponseService;
import com.citiustech.email.service.EmailSender;
import com.citiustech.email.util.EmailUtil;

@Service
public class JavaMailSenderService implements EmailSender {

	private final Logger log = LoggerFactory.getLogger(JavaMailSenderService.class);

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private EmailUtil emailUtil;

	@Autowired
	private EmailResponseService emailResponseService;

	@Override
	public void sendEmail(String htmlMessage, Set<String> reciepientEmails, String subject, Template template) throws MailException,MessagingException{

		if (!ObjectUtils.isEmpty(reciepientEmails)) {
			log.debug("Send email[multipart '{}' and html '{}'] to '{}' with subject '{}' and content={}",
					reciepientEmails, subject, htmlMessage);
			// Prepare message using a Spring helper
			MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			EmailResponse emailResponse = new EmailResponse();

			try {
				emailResponse.setRecipient(reciepientEmails);
				emailResponse.setSender(emailUtil.getSmtpUserName());
				emailResponse.setSentTime(LocalDateTime.now());
				emailResponse.setEmailType(template.toString());

				MimeMessageHelper message = new MimeMessageHelper(mimeMessage, StandardCharsets.UTF_8.name());
				message.setTo(reciepientEmails.stream().toArray(String[]::new));
				message.setSubject(subject);
				message.setText(htmlMessage, true);
				javaMailSender.send(mimeMessage);
				log.debug("Sent email to Users '{}'", reciepientEmails);
			} catch (MailException | MessagingException exception) {
				emailResponse.setErrorMessage(exception.getCause().getMessage());
				log.warn("Email could not be sent to users '{}':{}", reciepientEmails, exception.getMessage());
				throw exception;
			}
			emailResponseService.save(emailResponse);
		}
	}

}

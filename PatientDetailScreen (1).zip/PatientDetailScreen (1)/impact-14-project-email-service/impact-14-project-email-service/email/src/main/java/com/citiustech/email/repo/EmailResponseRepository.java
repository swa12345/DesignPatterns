package com.citiustech.email.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citiustech.email.entity.EmailResponse;

public interface EmailResponseRepository extends JpaRepository<EmailResponse, Integer>{

}

package com.citiustech.email.entity;

import java.util.Map;
import java.util.Set;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EmailInfo {

	Set<String> recipient;

	Map<String, Object> payload;

}

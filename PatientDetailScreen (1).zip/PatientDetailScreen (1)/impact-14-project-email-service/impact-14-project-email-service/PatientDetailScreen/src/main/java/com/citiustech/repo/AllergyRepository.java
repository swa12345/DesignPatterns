package com.citiustech.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.citiustech.model.Allergy;

@Repository
public interface AllergyRepository  extends CrudRepository<Allergy, String>{

	List<Allergy> findByAllergyType(String allergyType);
	
	@Query("SELECT DISTINCT allergyType FROM Allergy")
	List<String> getDistinctAllergyType();

	@Query("Select distinct allergyName From Allergy")
	List<String> getDistinctAllergyNames();
	
}

package com.citiustech.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.dto.PatientDTO;
import com.citiustech.exception.PatientNotFoundException;
import com.citiustech.model.Patient;
import com.citiustech.repo.PatientRepository;
import com.citiustech.service.PatientService;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	private PatientRepository patientRepository;

	@Override
	public List<PatientDTO> getAllPatientDetails() {
		Iterable<Patient> patients = patientRepository.findAll();
		List<PatientDTO> patientDTOs = new ArrayList<PatientDTO>();
		patients.forEach(patient -> {
			PatientDTO patientdto = new PatientDTO();
			patientdto.setPatientId(patient.getPatientId());
			patientdto.setTitle(patient.getTitle());
			patientdto.setFirstName(patient.getFirstName());
			patientdto.setLastName(patient.getLastName());
			patientdto.setDateofBirth(patient.getDateofBirth());
			patientdto.setAge(patient.getAge());
			patientdto.setGender(patient.getGender());
			patientdto.setRace(patient.getRace());
			patientdto.setEthnicity(patient.getEthnicity());
			patientdto.setLanguage(patient.getLanguage());
			patientdto.setEmailId(patient.getEmailId());
			patientdto.setHomeAddress(patient.getHomeAddress());
			patientdto.setContactNumber(patient.getContactNumber());
			patientdto.setEmergencyConatctInfo(patient.getEmergencyConatctInfo());
			patientdto.setAllergy(patient.getAllergy());
			patientdto.setIs_Allergic(patient.isIs_Allergic());
			patientDTOs.add(patientdto);
		});
		if (patientDTOs.isEmpty())
			throw new PatientNotFoundException("Service.PATIENTS_NOT_FOUND");
		return patientDTOs;
	}

	@Override
	public PatientDTO getPatientById(int pid) {
		Optional<Patient> patientinfo = patientRepository.findById(pid);
		Patient patient = patientinfo.orElseThrow(() -> new PatientNotFoundException("Service.PATIENT_NOT_FOUND"));
		PatientDTO patientdto = new PatientDTO();
		patientdto.setPatientId(patient.getPatientId());
		patientdto.setTitle(patient.getTitle());
		patientdto.setFirstName(patient.getFirstName());
		patientdto.setLastName(patient.getLastName());
		patientdto.setDateofBirth(patient.getDateofBirth());
		patientdto.setAge(patient.getAge());
		patientdto.setGender(patient.getGender());
		patientdto.setRace(patient.getRace());
		patientdto.setEthnicity(patient.getEthnicity());
		patientdto.setLanguage(patient.getLanguage());
		patientdto.setEmailId(patient.getEmailId());
		patientdto.setHomeAddress(patient.getHomeAddress());
		patientdto.setContactNumber(patient.getContactNumber());
		patientdto.setEmergencyConatctInfo(patient.getEmergencyConatctInfo());
		patientdto.setAllergy(patient.getAllergy());
		patientdto.setIs_Allergic(patient.isIs_Allergic());
		return patientdto;
	}

	@Override
	public PatientDTO addPatient(PatientDTO patientDTO) {
		Patient patient = new Patient();
		patient.setTitle(patientDTO.getTitle());
		patient.setFirstName(patientDTO.getFirstName());
		patient.setLastName(patientDTO.getLastName());
		patient.setDateofBirth(patientDTO.getDateofBirth());
		patient.setAge(patientDTO.getAge());
		patient.setGender(patientDTO.getGender());
		patient.setRace(patientDTO.getRace());
		patient.setEthnicity(patientDTO.getEthnicity());
		patient.setLanguage(patientDTO.getLanguage());
		patient.setEmailId(patientDTO.getEmailId());
		patient.setHomeAddress(patientDTO.getHomeAddress());
		patient.setContactNumber(patientDTO.getContactNumber());
		patient.setEmergencyConatctInfo(patientDTO.getEmergencyConatctInfo());
		patient.setAllergy(patientDTO.getAllergy());
		patient.setIs_Allergic(patient.isIs_Allergic());

		Patient patient2 = patientRepository.save(patient);

		PatientDTO patientDTO2 = new PatientDTO();
		patientDTO2.setTitle(patient2.getTitle());
		patientDTO2.setPatientId(patient2.getPatientId());
		patientDTO2.setFirstName(patient2.getFirstName());
		patientDTO2.setLastName(patient2.getLastName());
		patientDTO2.setDateofBirth(patient2.getDateofBirth());
		patientDTO2.setAge(patient2.getAge());
		patientDTO2.setGender(patient2.getGender());
		patientDTO2.setRace(patient2.getRace());
		patientDTO2.setEthnicity(patient2.getEthnicity());
		patientDTO2.setLanguage(patient2.getLanguage());
		patientDTO2.setEmailId(patient2.getEmailId());
		patientDTO2.setHomeAddress(patient2.getHomeAddress());
		patientDTO2.setContactNumber(patient2.getContactNumber());
		patientDTO2.setEmergencyConatctInfo(patient2.getEmergencyConatctInfo());
		patientDTO2.setAllergy(patient2.getAllergy());
		patientDTO2.setIs_Allergic(patient.isIs_Allergic());
		return patientDTO2;
	}

	@Override
	public PatientDTO updatePatient(int pid, PatientDTO patientDTO) {
		PatientDTO patientDTO2 = new PatientDTO();
		if (patientRepository.findById(pid).isPresent()) {
			Patient patient = patientRepository.findById(pid).get();
			if (patientDTO.getTitle() != null)
				patient.setTitle(patientDTO.getTitle());
			if (patientDTO.getFirstName() != null)
				patient.setFirstName(patientDTO.getFirstName());
			if (patientDTO.getLastName() != null)
				patient.setLastName(patientDTO.getLastName());
			if (patientDTO.getDateofBirth() != null)
				patient.setDateofBirth(patientDTO.getDateofBirth());
			if (patientDTO.getAge() != 0)
				patient.setAge(patientDTO.getAge());
			if (patientDTO.getGender() != null)
				patient.setGender(patientDTO.getGender());
			if (patientDTO.getRace() != null)
				patient.setRace(patientDTO.getRace());
			if (patientDTO.getEthnicity() != null)
				patient.setEthnicity(patientDTO.getEthnicity());
			if (patientDTO.getLanguage() != null)
				patient.setLanguage(patientDTO.getLanguage());
			if (patientDTO.getEmailId() != null)
				patient.setEmailId(patientDTO.getEmailId());
			if (patientDTO.getHomeAddress() != null)
				patient.setHomeAddress(patientDTO.getHomeAddress());
			if (patientDTO.getContactNumber() != 0)
				patient.setContactNumber(patientDTO.getContactNumber());
			if (patientDTO.getEmergencyConatctInfo() != null)
				patient.setEmergencyConatctInfo(patientDTO.getEmergencyConatctInfo());
			if (patientDTO.getAllergy() != null)
				patient.setAllergy(patientDTO.getAllergy());
			if (patientDTO.isIs_Allergic() != false)
				patient.setIs_Allergic(patient.isIs_Allergic());

			Patient patient2 = patientRepository.save(patient);

			patientDTO2.setPatientId(patient2.getPatientId());
			patientDTO2.setTitle(patient2.getTitle());
			patientDTO2.setFirstName(patient2.getFirstName());
			patientDTO2.setLastName(patient2.getLastName());
			patientDTO2.setDateofBirth(patient2.getDateofBirth());
			patientDTO2.setAge(patient2.getAge());
			patientDTO2.setGender(patient2.getGender());
			patientDTO2.setRace(patient2.getRace());
			patientDTO2.setEthnicity(patient2.getEthnicity());
			patientDTO2.setLanguage(patient2.getLanguage());
			patientDTO2.setEmailId(patient2.getEmailId());
			patientDTO2.setHomeAddress(patient2.getHomeAddress());
			patientDTO2.setContactNumber(patient2.getContactNumber());
			patientDTO2.setEmergencyConatctInfo(patient2.getEmergencyConatctInfo());
			patientDTO2.setAllergy(patient2.getAllergy());
			patientDTO2.setIs_Allergic(patient.isIs_Allergic());

			return patientDTO2;
		} else {
			throw new PatientNotFoundException("Service.PATIENT_NOT_FOUND");
		}

	}

}

package com.citiustech.service;

import java.util.List;

import com.citiustech.dto.PatientDTO;

public interface PatientService {

	public List<PatientDTO> getAllPatientDetails();

	public PatientDTO getPatientById(int pid);

	public PatientDTO addPatient(PatientDTO patient);

	public PatientDTO updatePatient(int pid,PatientDTO patientDTO);


}

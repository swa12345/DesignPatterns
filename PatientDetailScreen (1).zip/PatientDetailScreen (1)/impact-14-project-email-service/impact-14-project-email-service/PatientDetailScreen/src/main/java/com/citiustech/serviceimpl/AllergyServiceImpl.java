package com.citiustech.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.dto.AllergyDTO;
import com.citiustech.exception.AllergyNotFoundException;
import com.citiustech.model.Allergy;
import com.citiustech.repo.AllergyRepository;
import com.citiustech.service.AllergyService;

@Service
public class AllergyServiceImpl implements AllergyService {

	@Autowired
	private AllergyRepository allergyRepository;

	@Override
	public List<AllergyDTO> getAllAllergyDetails() {
		Iterable<Allergy> allergies = allergyRepository.findAll();
		List<AllergyDTO> allergieslist = new ArrayList<AllergyDTO>();
		allergies.forEach(allergy -> {
			AllergyDTO allergyDTO = new AllergyDTO();
			allergyDTO.setAllergyId(allergy.getAllergyId());
			allergyDTO.setAllergyType(allergy.getAllergyType());
			allergyDTO.setAllergyName(allergy.getAllergyName());
			allergyDTO.setIsoformsOrPartialSequencesOfAllergen(allergy.getIsoformsOrPartialSequencesOfAllergen());
			allergyDTO.setAllergySource(allergy.getAllergySource());
			allergyDTO.setAllerginicity(allergy.getAllerginicity());
			allergieslist.add(allergyDTO);
		});
		if(allergieslist.isEmpty()) {
			throw new AllergyNotFoundException("Service.ALLERGIES_NOT_FOUND");
		}
		return allergieslist;
	}

	@Override
	public AllergyDTO getAllergyById(String aId) {
		Optional<Allergy> allergies = allergyRepository.findById(aId);
		Allergy allergy = allergies.orElseThrow(() -> new AllergyNotFoundException("Service.ALLERGY_NOT_FOUND"));
		AllergyDTO allergyDTO = new AllergyDTO();
		allergyDTO.setAllergyId(allergy.getAllergyId());
		allergyDTO.setAllergyType(allergy.getAllergyType());
		allergyDTO.setAllergyName(allergy.getAllergySource());
		allergyDTO.setAllergySource(allergy.getAllergySource());
		allergyDTO.setIsoformsOrPartialSequencesOfAllergen(allergy.getIsoformsOrPartialSequencesOfAllergen());
		allergyDTO.setAllerginicity(allergy.getAllerginicity());
		return allergyDTO;
	}

	@Override
	public List<AllergyDTO> getAllergyByType(String aType) {
		List<Allergy> allergies = allergyRepository.findByAllergyType(aType);

		List<AllergyDTO> allergieslist = new ArrayList<AllergyDTO>();
		allergies.forEach(allergy -> {
			AllergyDTO allergyDTO = new AllergyDTO();
			allergyDTO.setAllergyId(allergy.getAllergyId());
			allergyDTO.setAllergyType(allergy.getAllergyType());
			allergyDTO.setAllergyName(allergy.getAllergyName());
			allergyDTO.setIsoformsOrPartialSequencesOfAllergen(allergy.getIsoformsOrPartialSequencesOfAllergen());
			allergyDTO.setAllergySource(allergy.getAllergySource());
			allergyDTO.setAllerginicity(allergy.getAllerginicity());
			allergieslist.add(allergyDTO);
		});
		return allergieslist;
	}

	@Override
	public List<String> getAllAllergiesType() {
		List<String> allergyTypes=allergyRepository.getDistinctAllergyType();
		return allergyTypes;
	}

	@Override
	public List<String> getAllAllergiesNames() {
		List<String> allergyNames=allergyRepository.getDistinctAllergyNames();
		return allergyNames;
	}

}

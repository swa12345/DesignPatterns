package com.citiustech.model;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "EmergencyContactInfo")
public class EmergencyContactInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int emergencyContactInfoId;
	private String title;
	private String firstName;
	private String lastName;
	private String relationship;
	private String emailId;
	private long contactNumber;
	private String homeAddress;
	private boolean portalAccess;
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getEmergencyContactInfoId() {
		return emergencyContactInfoId;
	}
	public void setEmergencyContactInfoId(int emergencyContactInfoId) {
		this.emergencyContactInfoId = emergencyContactInfoId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	public boolean isPortalAccess() {
		return portalAccess;
	}
	public void setPortalAccess(boolean portalAccess) {
		this.portalAccess = portalAccess;
	}
	public EmergencyContactInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmergencyContactInfo(int emergencyContactInfoId, String title, String firstName, String lastName,
			String relationship, String emailId, long contactNumber, String homeAddress, boolean portalAccess) {
		super();
		this.emergencyContactInfoId = emergencyContactInfoId;
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.relationship = relationship;
		this.emailId = emailId;
		this.contactNumber = contactNumber;
		this.homeAddress = homeAddress;
		this.portalAccess = portalAccess;
	}
	@Override
	public String toString() {
		return "EmergencyContactInfo [emergencyContactInfoId=" + emergencyContactInfoId + ", title=" + title
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", relationship=" + relationship
				+ ", emailId=" + emailId + ", contactNumber=" + contactNumber + ", homeAddress=" + homeAddress
				+ ", portalAccess=" + portalAccess + "]";
	}
	
	
	
}

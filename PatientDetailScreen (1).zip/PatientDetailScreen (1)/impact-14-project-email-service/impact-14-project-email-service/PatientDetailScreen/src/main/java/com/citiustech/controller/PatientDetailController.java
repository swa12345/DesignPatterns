package com.citiustech.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.dto.PatientDTO;
import com.citiustech.service.PatientService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping(value = "/api")
public class PatientDetailController {

	@Autowired
	private PatientService patientService;
	

	
	@GetMapping(value = "/patient")
	@ApiOperation(value = "List of All Patients" , response = Iterable.class)
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Succcessfully retrived list"),
			@ApiResponse(code = 401, message = "You are not authorised to view resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you  were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource are you trying to reach is not found"),
	})
	public ResponseEntity<List<PatientDTO>> getAllPatientDetails(){
		
		List<PatientDTO> patientlist=patientService.getAllPatientDetails();
		
		return new ResponseEntity<List<PatientDTO>>(patientlist, HttpStatus.OK);
	}
	
	@GetMapping(value="/patient/{id}")
	@ApiOperation(value = "Get Patient By ID" ,notes = "Provide an ID to get Patient Specific Data" ,response = PatientDTO.class)
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Succcessfully retrived Patient Details"),
			@ApiResponse(code = 401, message = "You are not authorised to view resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you  were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource are you trying to reach is not found"),
	})
	public ResponseEntity<PatientDTO> getPatientById(@PathVariable("id") int pid){
		PatientDTO patientDTO = patientService.getPatientById(pid);
		return new ResponseEntity<PatientDTO> (patientDTO,HttpStatus.OK);
	}
	
	@PostMapping(value="/patient")
	@ApiOperation(value = "Add New Patient" ,notes = "Filled all patient details", response = PatientDTO.class)
	@ApiResponses(value= {
			@ApiResponse(code = 201, message = "Added Succcessfully"),
			@ApiResponse(code = 401, message = "You are not authorised to view resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you  were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource are you trying to reach is not found"),
	})
	public ResponseEntity<PatientDTO> addPatient(@RequestBody PatientDTO patientDTO){
		PatientDTO patient = patientService.addPatient(patientDTO);
		return new ResponseEntity<PatientDTO>(patient,HttpStatus.CREATED);
	}

	@PutMapping(value="/patient/{id}")
	@ApiOperation(value = "Update Patient Details" ,notes = "Provide patient Id and Updated Patients data")
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Succcessfully Updated"),
			@ApiResponse(code = 401, message = "You are not authorised to view resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you  were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource are you trying to reach is not found"),
	})
	public ResponseEntity<PatientDTO> updatePatient(@PathVariable("id") int pid, @RequestBody PatientDTO patientDTO){
		PatientDTO patient = patientService.updatePatient(pid,patientDTO);
		return new ResponseEntity<PatientDTO>(patient,HttpStatus.OK);
	}

	

	
}

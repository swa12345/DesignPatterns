package com.citiustech.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.dto.AllergyDTO;
import com.citiustech.service.AllergyService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/api")
public class AllergyController {

	@Autowired
	private AllergyService allergyService;

	@GetMapping(value = "/allergy")
	@ApiOperation(value = "List of All Allergies" , response = Iterable.class)
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Succcessfully retrived list"),
			@ApiResponse(code = 401, message = "You are not authorised to view resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you  were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource are you trying to reach is not found"),
	})
	public ResponseEntity<List<AllergyDTO>> getAllAllergy() {

		List<AllergyDTO> allergylist = allergyService.getAllAllergyDetails();
		return new ResponseEntity<List<AllergyDTO>>(allergylist, HttpStatus.OK);
	}

	@GetMapping(value = "/allergy/{id}")
	@ApiOperation(value = "Get Allergy By ID" ,notes = "Provide an ID to get Allergy Specific Data" ,response = AllergyDTO.class)
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Succcessfully retrived Allergy Details"),
			@ApiResponse(code = 401, message = "You are not authorised to view resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you  were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource are you trying to reach is not found"),
	})
	public ResponseEntity<AllergyDTO> getAllergyById(@PathVariable("id") String aId) {
		AllergyDTO allergyDTO = allergyService.getAllergyById(aId);
		return new ResponseEntity<AllergyDTO>(allergyDTO, HttpStatus.OK);
	}

	@GetMapping(value = "/allergy/type/{type}")
	@ApiOperation(value = "Get Allergies list under specific AllergyType" ,notes = "Provide an Allergies list under specific Types" ,response = AllergyDTO.class)
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Succcessfully retrived Allergies"),
			@ApiResponse(code = 401, message = "You are not authorised to view resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you  were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource are you trying to reach is not found"),
	})
	public ResponseEntity<List<AllergyDTO>> getAllergyByType(@PathVariable("type") String aType) {
		List<AllergyDTO> allergyDTOs = allergyService.getAllergyByType(aType);
		return new ResponseEntity<List<AllergyDTO>>(allergyDTOs, HttpStatus.OK);
	}

	@GetMapping(value = "/allergy/type")
	@ApiOperation(value = "list of AllergyTypes" ,response = AllergyDTO.class)
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Succcessfully retrived Allergy Types"),
			@ApiResponse(code = 401, message = "You are not authorised to view resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you  were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource are you trying to reach is not found"),
	})
	public ResponseEntity<List<String>> getAllAllergiesType() {
		List<String> allergytypes = allergyService.getAllAllergiesType();
		return new ResponseEntity<List<String>>(allergytypes, HttpStatus.OK);
	}
	
	@GetMapping(value = "/allergy/names")
	@ApiOperation(value = "list of Allergy names" ,response = AllergyDTO.class)
	@ApiResponses(value= {
			@ApiResponse(code = 200, message = "Succcessfully retrived Allergy Names"),
			@ApiResponse(code = 401, message = "You are not authorised to view resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you  were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource are you trying to reach is not found"),
	})
	public ResponseEntity<List<String>> getAllAllergiesNames() {
		List<String> allergyNames = allergyService.getAllAllergiesNames();
		return new ResponseEntity<List<String>>(allergyNames, HttpStatus.OK);
	}
}

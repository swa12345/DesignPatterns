package com.citiustech.dto;



public class EmergencyContactInfoDTO {

	private int emergencyContactInfoId;
	private String firstName;
	private String lastName;
	private String relationship;
	private String emailId;
	private long contactNumber;
	private String homeAddress;
	private boolean portalAccess;
	public int getEmergencyContactInfoId() {
		return emergencyContactInfoId;
	}
	public void setEmergencyContactInfoId(int emergencyContactInfoId) {
		this.emergencyContactInfoId = emergencyContactInfoId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	public boolean isPortalAccess() {
		return portalAccess;
	}
	public void setPortalAccess(boolean portalAccess) {
		this.portalAccess = portalAccess;
	}

	
	
	public EmergencyContactInfoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmergencyContactInfoDTO(int emergencyContactInfoId, String firstName, String lastName, String relationship,
			String emailId, long contactNumber, String homeAddress, boolean portalAccess) {
		super();
		this.emergencyContactInfoId = emergencyContactInfoId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.relationship = relationship;
		this.emailId = emailId;
		this.contactNumber = contactNumber;
		this.homeAddress = homeAddress;
		this.portalAccess = portalAccess;
	}
	@Override
	public String toString() {
		return "EmergencyContactInfo [emergencyContactInfoId=" + emergencyContactInfoId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", relationship=" + relationship + ", emailId=" + emailId
				+ ", contactNumber=" + contactNumber + ", homeAddress=" + homeAddress + ", portalAccess=" + portalAccess
				+ "]";
	}
	
	
}

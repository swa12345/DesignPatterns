package com.citiustech.util;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.citiustech.exception.AllergyNotFoundException;
import com.citiustech.exception.PatientNotFoundException;

@RestControllerAdvice
public class ExceptionControllerAdvice {

	@Autowired
	Environment environment;

	@ExceptionHandler(PatientNotFoundException.class)
	public ResponseEntity<ErrorInfo> handlePatientNotFoundException(PatientNotFoundException exception) {
		ErrorInfo error = new ErrorInfo();
		error.setErrorMessage(environment.getProperty(exception.getMessage()));
		error.setTimestamp(LocalDateTime.now());
		error.setErrorCode(HttpStatus.NOT_FOUND.value()); 
		return new ResponseEntity<ErrorInfo>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(AllergyNotFoundException.class)
	public ResponseEntity<ErrorInfo> handleAllergyNotFoundException(AllergyNotFoundException exception) {
		ErrorInfo error = new ErrorInfo();
		error.setErrorMessage(environment.getProperty(exception.getMessage()));
		error.setTimestamp(LocalDateTime.now());
		error.setErrorCode(HttpStatus.NOT_FOUND.value()); 
		return new ResponseEntity<ErrorInfo>(error, HttpStatus.NOT_FOUND);
	}
}

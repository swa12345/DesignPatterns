package com.citiustech.exception;

public class AllergyNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AllergyNotFoundException(String message) {
		super(message);
	}
}

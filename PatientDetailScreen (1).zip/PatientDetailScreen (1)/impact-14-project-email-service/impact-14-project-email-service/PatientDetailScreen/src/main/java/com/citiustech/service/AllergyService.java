package com.citiustech.service;

import java.util.List;

import com.citiustech.dto.AllergyDTO;

public interface AllergyService {

	public List<AllergyDTO> getAllAllergyDetails();

	public AllergyDTO getAllergyById(String aId);

	public List<AllergyDTO> getAllergyByType(String aType);

	public List<String> getAllAllergiesType();

	public List<String> getAllAllergiesNames();

}

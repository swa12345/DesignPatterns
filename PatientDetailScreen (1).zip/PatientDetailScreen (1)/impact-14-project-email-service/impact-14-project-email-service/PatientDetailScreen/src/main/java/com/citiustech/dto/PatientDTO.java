package com.citiustech.dto;

import java.time.LocalDate;
import java.util.List;

import com.citiustech.model.Allergy;
import com.citiustech.model.EmergencyContactInfo;
import com.fasterxml.jackson.annotation.JsonFormat;


public class PatientDTO {

	private int patientId;
	private String title;
	private String firstName;
	private String lastName;
	private String emailId;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	private LocalDate dateofBirth;
	private int age;
	private String gender;
	private String race;
	private String ethnicity;
	private String language;
	private String homeAddress;
	private long contactNumber;
	private boolean is_Allergic;
	
	private List<Allergy> allergy;
	
	private List<EmergencyContactInfo> emergencyConatctInfo;

	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public LocalDate getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(LocalDate dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getEthnicity() {
		return ethnicity;
	}

	public void setEthnicity(String ethnicity) {
		this.ethnicity = ethnicity;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public boolean isIs_Allergic() {
		return is_Allergic;
	}

	public void setIs_Allergic(boolean is_Allergic) {
		this.is_Allergic = is_Allergic;
	}

	public List<Allergy> getAllergy() {
		return allergy;
	}

	public void setAllergy(List<Allergy> allergy) {
		this.allergy = allergy;
	}

	public List<EmergencyContactInfo> getEmergencyConatctInfo() {
		return emergencyConatctInfo;
	}

	public void setEmergencyConatctInfo(List<EmergencyContactInfo> emergencyConatctInfo) {
		this.emergencyConatctInfo = emergencyConatctInfo;
	}


	public PatientDTO(int patientId, String title, String firstName, String lastName, String emailId, LocalDate dateofBirth,
			int age, String gender, String race, String ethnicity, String language, String homeAddress,
			long contactNumber, boolean is_Allergic, List<Allergy> allergy,
			List<EmergencyContactInfo> emergencyConatctInfo) {
		super();
		this.patientId = patientId;
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dateofBirth = dateofBirth;
		this.age = age;
		this.gender = gender;
		this.race = race;
		this.ethnicity = ethnicity;
		this.language = language;
		this.homeAddress = homeAddress;
		this.contactNumber = contactNumber;
		this.is_Allergic = is_Allergic;
		this.allergy = allergy;
		this.emergencyConatctInfo = emergencyConatctInfo;
	}

	public PatientDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "PatientDTO [patientId=" + patientId + ", title=" + title + ", firstName=" + firstName + ", lastName="
				+ lastName + ", emailId=" + emailId + ", dateofBirth=" + dateofBirth + ", age=" + age + ", gender="
				+ gender + ", race=" + race + ", ethnicity=" + ethnicity + ", language=" + language + ", homeAddress="
				+ homeAddress + ", contactNumber=" + contactNumber + ", is_Allergic=" + is_Allergic + ", allergy="
				+ allergy + ", emergencyConatctInfo=" + emergencyConatctInfo + "]";
	}

	
	
	
}

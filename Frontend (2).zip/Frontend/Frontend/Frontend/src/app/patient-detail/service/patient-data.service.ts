import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PatientDataService {
 
  constructor(private http:HttpClient) { }

  API_URL: string = 'http://localhost:8080/api';

  savePatientExtraDetails(request: any) {
    console.log(request);
    let requestOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + localStorage.getItem('token'),
      }),
    };
    return this.http.post<any>(this.API_URL + '/patient', request,requestOptions);
  }

  public getPatientDetails(empid: any): Observable<any> {
    let requestOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + localStorage.getItem('token'),
      }),
    };
    console.log("patient service called")
    // return this.http.get<any>(this.API_URL + '/patient/' + empid,requestOptions);
    return this.http.get<any>(this.API_URL + '/patient/' + empid,requestOptions);
  }
}

import { TestBed } from '@angular/core/testing';

import { AllergyDataService } from './allergy-data.service';

describe('AllergyDataService', () => {
  let service: AllergyDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AllergyDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

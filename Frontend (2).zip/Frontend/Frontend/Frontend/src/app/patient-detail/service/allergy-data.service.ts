import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AllergyDataService {
  API_URL: string = "http://localhost:8080/api";
  constructor(private http:HttpClient) { }
   requestOptions = {
    headers: new HttpHeaders({
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    }),
  };

  fetchAllergyTypeFromDatabase(): Observable<any>{
    return this.http.get<string[]>(this.API_URL + '/allergy/type',this.requestOptions);
  }

  fetchAllergyNameFromDatabase(allergyType:string){
    return this.http.get<string[]>(this.API_URL + '/allergy/names/' + allergyType,this.requestOptions);
  }

  getAllergySourceByTypeAndName(type:any,name:any){
    return this.http.get<string[]>(this.API_URL + '/allergy/' + type + '/' + name,this.requestOptions);
  }

  getAllergyIsoformByTypeAndNameAndDescription(type:any,name:any,allergen:any){
    return this.http.get<string[]>(this.API_URL + '/allergy/' + type + '/' + name + '/' + allergen,this.requestOptions);
  }

  getAllergyIdByTypeAndNameAndDescriptionAndIsoform(type:any,name:any,allergen:any,isoform:any){
    return this.http.get<string[]>(this.API_URL + '/allergy/' + type + '/' + name + '/' + allergen + '/' + isoform,this.requestOptions);
  }
}

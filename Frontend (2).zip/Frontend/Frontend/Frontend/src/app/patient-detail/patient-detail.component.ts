import { formatDate } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';
import { AllergyDataService } from './service/allergy-data.service';
import { PatientDataService } from './service/patient-data.service';

@Component({
  selector: 'app-patient-detail',
  templateUrl: './patient-detail.component.html',
  styleUrls: ['./patient-detail.component.css'],
})
export class PatientDetailComponent implements OnInit {
  constructor(
    private _formBuilder: FormBuilder,
    private allergyservice: AllergyDataService,
    private patientservice: PatientDataService,
    private route: Router,
    private toast: NgToastService
  ) {}

  @Input() max: any;
  tomorrow = new Date();

  isEditable = false;

  ngOnInit(): void {
    this.getPatientDataFromDatabase();
  }

  val: any;
  datevalue: string;
  toppings = new FormControl('');

  titles: string[] = ['Mr.', 'Mrs.', 'Ms'];
  accessportals: string[] = ['Yes', 'No'];
  genders: string[] = ['Male', 'Female', 'Other'];
  states: string[] = ['Father', 'Mother', 'Sibling', 'Spouse', 'Friend'];
  patientDetails: any;
  emergencyContactDetails: any;
  allergyDetails: any;

  allergyType: any[] = [];
  selectedAllergyType: string;
  allergyName: string[] = [];
  selectedAllergyName: string;
  allergenSource: string[] = [];
  selectedAllergenSource: string;
  allergyIsoform: string[] = [];
  selectedAllergyIsoform: string;
  allergycodes: string[] = [];
  selectedAllergyId: string;

  patientsdata = new Patientsdata();
  getPatientDataFromDatabase() {
    let token = localStorage.getItem('token');
    let payload = JSON.parse(atob(token.split('.')[1]));
    let patientId = payload.userId;
    this.patientservice.getPatientDetails(patientId).subscribe((response) => {
      console.log(response);
      this.patientsdata = response;
    });
  }

  getAllergyNameByType(event: any) {
    this.selectedAllergyType = event.value;

    this.allergyservice
      .fetchAllergyNameFromDatabase(this.selectedAllergyType)
      .subscribe({
        next: (response) => {
          this.allergyName = response;
        },
        error: (e) => {
          this.toast.error({
            detail: 'Something went wrong',
            summary: '',
            duration: 2000,
          });
        },
      });
  }

  getAllergySource(event: any) {
    this.selectedAllergyName = event.value;

    this.allergyservice
      .getAllergySourceByTypeAndName(
        this.selectedAllergyType,
        this.selectedAllergyName
      )
      .subscribe({
        next: (response) => {
          this.allergenSource = response;
        },
        error: (e) => {
          this.toast.error({
            detail: 'Something went wrong',
            summary: '',
            duration: 2000,
          });
        },
      });
  }

  getAllergyIsoform(event: any) {
    this.selectedAllergenSource = event.value;
    this.allergyservice
      .getAllergyIsoformByTypeAndNameAndDescription(
        this.selectedAllergyType,
        this.selectedAllergyName,
        this.selectedAllergenSource
      )
      .subscribe({
        next: (response) => {
          this.allergyIsoform = response;
        },
        error: (e) => {
          this.toast.error({
            detail: 'Something went wrong',
            summary: '',
            duration: 2000,
          });
        },
      });
  }
  getAllergyId(event: any) {
    this.selectedAllergyIsoform = event.value;
    this.allergyservice
      .getAllergyIdByTypeAndNameAndDescriptionAndIsoform(
        this.selectedAllergyType,
        this.selectedAllergyName,
        this.selectedAllergenSource,
        this.selectedAllergyIsoform
      )
      .subscribe({
        next: (response) => {
          this.allergycodes = response;
        },
        error: (e) => {
          this.toast.error({
            detail: 'Something went wrong',
            summary: '',
            duration: 2000,
          });
        },
      });
  }

  showAge: any;
  ageCalculator() {
    if (this.firstFormGroup.get('dateOfBirth')) {
      const convertAge = this.firstFormGroup.get('dateOfBirth').value;
      const timeDiff = Math.abs(Date.now() - convertAge.getTime());
      this.showAge = Math.floor(timeDiff / (1000 * 3600 * 24) / 365);
      console.log(this.showAge);
    }
  }
  firstFormGroup = this._formBuilder.group({
    // firstCtrl: ['', Validators.required],
    title: new FormControl(),
    firstName: new FormControl(),
    lastName: new FormControl(),
    email: new FormControl(),
    gender: new FormControl(),
    dateOfBirth: new FormControl(),
    age: new FormControl(),
    languages: new FormControl(),
    race: new FormControl(),
    ethnicity: new FormControl(),
    homeAddress: new FormControl(),
    contactNumber: new FormControl(),
  });

  secondFormGroup = this._formBuilder.group({
    // secondCtrl: ['', Validators.required],
    etitle: new FormControl(),
    efname: new FormControl(),
    elname: new FormControl(),
    erelationship: new FormControl(),
    eemail: new FormControl('', [Validators.required, Validators.email]),
    econtact: new FormControl(),
    ehomeaddress: new FormControl(),
    eportalAccess: new FormControl(),
  });

  firstFormGroupAddress: string = '';
  formContol1Data() {
    // this.firstFormGroupAddress = this.firstFormGroup.get('homeAddress')?.value;
  }

  portalaccessboolean(values: string) {
    if (values === 'Yes') {
      return true;
    } else {
      return 'false';
    }
  }

  emergencyContactDetailsMethod() {
    this.emergencyContactDetails = {
      title: this.secondFormGroup.get('etitle').value.toString(),
      firstName: this.secondFormGroup.get('efname')?.value,
      lastName: this.secondFormGroup.get('elname')?.value,
      relationship: this.secondFormGroup.get('erelationship').value.toString(),
      emailId: this.secondFormGroup.get('eemail')?.value,
      contactNumber: this.secondFormGroup.get('econtact')?.value,
      homeAddress: this.secondFormGroup.get('ehomeaddress')?.value,
      portalAccess: this.portalaccessboolean(
        this.secondFormGroup.get('eportalAccess').value.toString()
      ),
    };
    return Array.of(this.emergencyContactDetails);
  }

  copyAddress(event: any) {
    if (event.checked) {
      this.firstFormGroupAddress =
        this.firstFormGroup.get('homeAddress')?.value;
    } else {
      this.firstFormGroupAddress = '';
    }
  }

  thirdFormGroup = this._formBuilder.group({
    //thirdCtrl: ['', Validators.required],
    allergyCode: new FormControl(),
  });

  allegyDetailsMethod() {
    this.allergyDetails = {
      allergyId: this.thirdFormGroup.get('allergyCode')?.value.toString(),
      allergyType: this.selectedAllergyType,
      allergyName: this.selectedAllergyName,
      allergyS: this.selectedAllergenSource.toString(),
      allergyClinicalInfo: this.selectedAllergyIsoform,
    };
    return Array.of(this.allergyDetails);
  }

  patientDetailsMethod() {
    let token = localStorage.getItem('token');
    let payload = JSON.parse(atob(token.split('.')[1]));
    let patientid = payload.userId;
    this.val = this.firstFormGroup.get('dateOfBirth').value;
    this.datevalue = formatDate(this.val, 'MM/dd/yyyy', 'en');
    this.patientDetails = {
      patientId: patientid,
      title: this.firstFormGroup.get('title').value.toString(),
      firstName: this.firstFormGroup.get('firstName')?.value,
      lastName: this.firstFormGroup.get('lastName')?.value,
      emailId: this.firstFormGroup.get('email')?.value,
      age: this.showAge,
      gender: this.firstFormGroup.get('gender').value.toString(),
      dateofBirth: this.datevalue.toString(),
      race: this.firstFormGroup.get('race')?.value,
      ethnicity: this.firstFormGroup.get('ethnicity')?.value,
      language: this.firstFormGroup.get('languages')?.value,
      homeAddress: this.firstFormGroup.get('homeAddress')?.value,
      emergencyContactInfo: this.emergencyContactDetailsMethod(),
      isAllergic: true,
      contactNumber: this.firstFormGroup.get('contactNumber')?.value,
      allergy: this.allegyDetailsMethod(),
    };
    return this.patientDetails;
  }

  collectAllData() {
    console.log(
      this.patientservice.savePatientExtraDetails(this.patientDetailsMethod())
    );
    this.patientservice
      .savePatientExtraDetails(this.patientDetailsMethod())
      .subscribe({
        next: (response) => {
          this.toast.success({
            detail: response.message,
            summary: '',
            duration: 2000,
          });
          //this.route.navigate(['patient/dashboard']);
          alert('Details Updated!')
        },
        error: (e) => {
          this.toast.error({
            detail: e.message,
            summary: 'Please try again',
            duration: 2000,
          });
        },
      });
  }

  loadAllergyTypeDataFromBackend() {
    this.allergyservice.fetchAllergyTypeFromDatabase().subscribe({
      next: (response) => {
        this.allergyType = response;
      },
      error: (e) => {
        this.toast.error({
          detail: 'Something went wrong',
          summary: '',
          duration: 2000,
        });
      },
    });
  }
}

export class Patientsdata {
  constructor(
    public patientId?: number,
    public title?: string,
    public age?: number,
    public gender?: string,
    public race?: string,
    public ethnicity?: string,
    public language?: string,
    public is_Allergic?: string,
    public allergy?: any,
    public emergencyContactInfo?: any,
    public firstName?: string,
    public lastName?: string,
    public emailId?: string,
    public homeAddress?: string,
    public contactNumber?: number
  ) {}
}

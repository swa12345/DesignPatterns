import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginModule } from './login/login.module';
import { HttpClientModule } from '@angular/common/http';
import { RegistrationModule } from './registration/registration.module';
import { RouterModule } from '@angular/router';
import { NgToastModule } from 'ng-angular-popup';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { PatientDetailComponent } from './patient-detail/patient-detail.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PatientHistoryComponent } from './patient-history/patient-history.component';
import { PatientVisitComponent } from './patient-visit/patient-visit.component';
import { DoctorAppointmentComponent } from './doctor-appointment/doctor-appointment.component';
import { AddAppointmentComponent } from './doctor-appointment/add-appointment/add-appointment.component';
import { ViewAppointmentComponent } from './doctor-appointment/view-appointment/view-appointment.component';
import { PatientAppointmentComponent } from './patient-appointment/patient-appointment.component';
import { PatientAddAppointmentComponent } from './patient-appointment/patient-add-appointment/patient-add-appointment.component';
import { PatientViewAppointmentComponent } from './patient-appointment/patient-view-appointment/patient-view-appointment.component';

@NgModule({
  declarations: [
    AppComponent,
    PatientDetailComponent,
    PatientHistoryComponent,
    PatientVisitComponent,
    DoctorAppointmentComponent,
    AddAppointmentComponent,
    ViewAppointmentComponent,
    PatientAppointmentComponent,
    PatientAddAppointmentComponent,
    PatientViewAppointmentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LoginModule,
    HttpClientModule,
    RegistrationModule,
    RouterModule,
    NgToastModule,
    BrowserAnimationsModule,
    MaterialModule,
    DashboardModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

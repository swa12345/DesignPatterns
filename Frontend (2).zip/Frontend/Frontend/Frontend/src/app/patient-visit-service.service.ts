import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { JwtHelperService } from "@auth0/angular-jwt";

@Injectable({
  providedIn: 'root'
})
export class PatientVisitServiceService {
  requestOptions = {                                                                                                                                                                                
    headers: new HttpHeaders({ Authorization: "Bearer " + localStorage.getItem("token")})
  };

  private baseUrl:string="http://localhost:8081";
  

  constructor(private http:HttpClient) { }

  sendPatientVisitDetails(data:any){
  
    // let token = localStorage.getItem('token');
    // let headers = new Headers();

    // headers.append('Authorization', 'Bearer '+token);

    // let options = { headers: headers };
    
    return this.http.post(`${this.baseUrl}/patientvisit/addPatientVisitDetails`, this.requestOptions, data);

    // return this.http.post(`${this.baseUrl}/patientvisit/addPatientVisitDetails`,data);
  }

  // getMedication() {
  //   let token = localStorage.getItem('token');
  //   let headers = new Headers();

  //   headers.append('Authorization', 'Bearer '+token);

  //   let options1 = { headers: headers };
  //   return this.http.get(`${this.baseUrl}/patientvisit/getMedicationDetails`,options1);
  // }

 
}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http : HttpClient) { }

  userRole : BehaviorSubject<string> = new BehaviorSubject("");

  API_URL: String = "http://localhost:8300";

  authenticateUser(request: any){
    return this.http.post(this.API_URL + "/user/login", request, {responseType: 'text'});
  }

  getUserFirstName() : string{
   let token : any = localStorage.getItem("token");
    return JSON.parse(atob(token.split(".")[1])).firstName;
}

logout(){

  let requestOptions = {                                                                                                                                                                                

    headers: new HttpHeaders({ Authorization: "Bearer " + localStorage.getItem("token")})

  };
  localStorage.removeItem("token");
  return this.http.delete<any>(this.API_URL + "/authenticate/logout", requestOptions);

}
}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  private patientId!: number; // get from router outlet
  requestOptions = {                                                                                                                                                                                
    headers: new HttpHeaders({ Authorization: "Bearer " + localStorage.getItem("token")})
  };

  // http://localhost:8300/user/physicians
  private get_url: string = "http://localhost:8082/view-appointments";
  private get_url_physicianId: string = "";
  private post_url: string = "http://localhost:8082/add-appointment";
  private put_url: string = "http://localhost:8082/update-appointment"
  private del_url: string = "http://localhost:8082/delete-appointment/";
  

  constructor(private http: HttpClient) { }

  // get all appointments
  getAppointments() {
    return this.http.get(this.get_url);
  }

  // get appointments by physician Id
  getAppointmentsById(physicianId: any) {
    // let requestOptions = {                                                                                                                                                                                
    //   headers: new HttpHeaders({ Authorization: "Bearer " + localStorage.getItem("token")})
    // };

    return this.http.get(this.get_url + "/" + physicianId, this.requestOptions);
  }

  addAppointment(data: any) {
    return this.http.post(this.post_url, data, this.requestOptions);
  }

  updateAppointment(data: any) {
    return this.http.put(this.put_url, data, this.requestOptions);
  }

  deleteAppointment(id: number) {
    console.log(this.del_url + id);
    return this.http.delete(this.del_url + id, this.requestOptions);
  }

  fetchPatientFromDatabase(): Observable<any>{
    console.log('Inside service');
    return this.http.get("http://localhost:8300/user/physicians", this.requestOptions);

  }
}

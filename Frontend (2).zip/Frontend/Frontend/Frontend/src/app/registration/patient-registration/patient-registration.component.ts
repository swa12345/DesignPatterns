import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient',
  templateUrl: './patient-registration.component.html',
  styleUrls: ['./patient-registration.component.css']
})
export class PatientRegistrationComponent implements OnInit {

  email: String = '';
  password: String = '';
  title: String = '';
  firstName: String = '';
  lastName: String = '';
  contact: number = 0;

  constructor(private http : HttpClient, private route : Router) { }

  ngOnInit(): void {
  }

  onSubmit(){
    // let headers = new Headers();
    // headers.append('Access-Control-Request-Headers', '*');
    // let options = { headers: headers };
    this.http.post('http://localhost:8300/user/register',
    {
      emailId: this.email,
      password: this.password,
      firstName: this.firstName,
      lastName: this.lastName,
      contact: this.contact,
      title: this.title,
      status: {
        statusId: 1,
        code : 'Active'
      }
    },
    {responseType: 'text'})
    .subscribe(response => {
      //console.log('Response from Login Service ', response);
      alert('Patient Registered Successfully!')
      this.route.navigate(['login']);
    })
  }

}

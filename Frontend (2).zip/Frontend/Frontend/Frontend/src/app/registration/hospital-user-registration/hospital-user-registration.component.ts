import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-hospital-user-registration',
  templateUrl: './hospital-user-registration.component.html',
  styleUrls: ['./hospital-user-registration.component.css']
})
export class HospitalUserRegistrationComponent implements OnInit {

  email: String = '';
  password: String = '';
  title: String = '';
  firstName: String = '';
  lastName: String = '';
  contact: number = 0;
  role : any

  constructor(private http : HttpClient, private route : Router) { }

  ngOnInit(): void {
  }

  onSubmit(){
    // let headers = new Headers();
    // headers.append('Access-Control-Request-Headers', '*');
    // let options = { headers: headers };
    this.http.post('http://localhost:8300/user/register',
    {
      emailId: this.email,
      password: this.password,
      firstName: this.firstName,
      lastName: this.lastName,
      contact: this.contact,
      title: this.title,
      status: {
        id: 1,
        code: 'Active'
      }
    },
    {responseType: 'text'})
    .subscribe(response => {
      console.log('Response from Login Service ', response);
      this.route.navigate(['login']);
    })
  }

}

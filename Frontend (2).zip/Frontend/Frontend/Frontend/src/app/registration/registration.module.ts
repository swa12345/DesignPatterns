import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientRegistrationComponent } from './patient-registration/patient-registration.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HospitalUserRegistrationComponent } from './hospital-user-registration/hospital-user-registration.component';



@NgModule({
  declarations: [
    PatientRegistrationComponent,
    HospitalUserRegistrationComponent
  ],
  exports: 
  [PatientRegistrationComponent,
    HospitalUserRegistrationComponent
  ],
  
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ]
})
export class RegistrationModule { }

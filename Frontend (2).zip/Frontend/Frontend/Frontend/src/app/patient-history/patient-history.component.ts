import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


export class PatientHistory {
  
  constructor(
    public blood_Pressure: string,
    public body_Temparature: string,
    public diagnosis:any,
    public employee_Id: string,
    public height: boolean,
    public medication: any,
    public patient_Id: string,
    public procedure: any,
    public respiration_Rate: string,
    public visit_Date: string,
    public visit_Id: string,
    public weight: string,
    public notes:string
  
  ) {
  }
}


@Component({
  selector: 'app-patient-history',
  templateUrl: './patient-history.component.html',
  styleUrls: ['./patient-history.component.css']
})
export class PatientHistoryComponent implements OnInit {
  requestOptions = {                                                                                                                                                                                
    headers: new HttpHeaders({ Authorization: "Bearer " + localStorage.getItem("token")})
  };
  
  disabled=true;
  patientId:number;
  // doctorId:number;
  patientHistory:PatientHistory[];
  // patientHistory:Array<PatientHistory>;
  // empIds:Set<string>=new Set<string>();
  // empIdNameMap:Map<string,string>=new Map<string,string>();
  diagnosis1:[]
  
  
 
  obj:any;
  constructor(private activatedRoute: ActivatedRoute,private httpClient:HttpClient) {}

  async ngOnInit(){
    this.activatedRoute.params.subscribe(s => {
      this.patientId=s["patientId"];  
      
  });
  this.getPatientVisitHistory();
  // console.log("$$$$$$$$$$$$$$$$",this.empIds.size);
  
  
  
  }

  // async getPatientVisitHistory():Promise<void>{
  //   this.httpClient.get<any>(`http://localhost:8081/patientvisit/getPatientVisitHistory/${this.patientId}`).subscribe(
  //     response=>{
  //       // console.log(response);
  //       this.patientHistory=response;
  //       this.patientHistory.forEach((ph:PatientHistory)=>{
  //         console.log("************************************");
          
  //         this.empIds.add(ph.employee_Id);
          
  //       });

      getPatientVisitHistory(){
          this.httpClient.get<any>(`http://localhost:8081/patientvisit/getPatientVisitHistory/${this.patientId}`, this.requestOptions).subscribe(
            response=>{
              
              this.patientHistory=response;
              // console.log(this.patientHistory);
                
              });
      //   this.empIds.forEach(v=>{
      //     this.getDoctorName(v);
      // })
        // console.log(this.empIds)
        // console.log(this.patientHistory);
        // console.log(this.patientHistory);
        // console.log(this.patientHistory[0].employee_Id);
        // this.a=this.patientHistory[0];
        // console.log(this.a);
      }
    // )
  // }    

  // getDoctorName(empId:string){
  //   console.log("****************************1234");
    
  //   this.httpClient.get<any>(`http://localhost:8300/user/${empId}`).subscribe(
  //     response=>{
  //       this.empIdNameMap.set(empId,response);
  //       console.log(this.empIdNameMap)
  //     }
  //   )
  // }
  // http://localhost:8300/user/users/

}

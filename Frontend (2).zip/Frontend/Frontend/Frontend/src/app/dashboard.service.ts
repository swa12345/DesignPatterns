import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private http : HttpClient) { }
  API_URL : string = "http://localhost:8300";
  getAllUsersCount(){
    let requestOptions = {                                                                                                                                                                                 
      headers: new HttpHeaders({ Authorization: "Bearer " + localStorage.getItem("token")})
    };

    return this.http.get<any>(this.API_URL + "/user/count", requestOptions);
  }
}

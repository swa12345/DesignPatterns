import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddAppointmentComponent } from './doctor-appointment/add-appointment/add-appointment.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CTHospital';

  constructor(public dialog: MatDialog) {}
  
  addAppointment() {
    const dialogRef = this.dialog.open(AddAppointmentComponent);
  }
}

import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { AppointmentService } from 'src/app/appointment.service';
import { PatientAddAppointmentComponent } from '../patient-add-appointment/patient-add-appointment.component';

@Component({
  selector: 'app-patient-view-appointment',
  templateUrl: './patient-view-appointment.component.html',
  styleUrls: ['./patient-view-appointment.component.css']
})
export class PatientViewAppointmentComponent implements OnInit {

  appointments: any;
  physicianId: any;

  constructor(private route: ActivatedRoute,
     public dialog: MatDialog,
     private appointmentService: AppointmentService) { 
      this.getAppointmentsById();
    }

  ngOnInit(): void {
    // this.route.params.subscribe(param => {
    //   console.log(param['doctor-id']); 
    // })

    
    this.getAppointmentsById();
    
  }

  getAppointmentsById() {
    // this.appointments = this.service.getAppointments();
    let token : any = localStorage.getItem("token");

    this.physicianId = JSON.parse(atob(token.split(".")[1])).userId;
    console.log(this.physicianId, " - This is physician Id");
    this.appointmentService.getAppointmentsById(this.physicianId).subscribe(data => {
      this.appointments = data;
      console.log(this.appointments);
    })
  }

  editAppointment(editData: any) {
    const dialogRef = this.dialog.open(PatientAddAppointmentComponent, {
      data: editData
    }).afterClosed().subscribe(val => {
      if (val === 'update') {
        this.getAppointmentsById();
      }
    })
    // console.log("card clicked");
    //console.log(editData);
  }

  deleteAppointment(id: number) {
    this.appointmentService.deleteAppointment(id)
    .subscribe({
      next: (res) => {
        alert("Appointment deleted successfully");
        this.getAppointmentsById();
      },
      error: () => {
        alert("Error while deleting the record");
      }
    })
  }

}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AppointmentService } from 'src/app/appointment.service';

@Component({
  selector: 'app-patient-add-appointment',
  templateUrl: './patient-add-appointment.component.html',
  styleUrls: ['./patient-add-appointment.component.css']
})
export class PatientAddAppointmentComponent implements OnInit {

  editBtn: string = "Save";
  appointmentForm!: FormGroup;
  physicians: any;
  selectedPhysician: any;

  requestOptions = {                                                                                                                                                                                
    headers: new HttpHeaders({ Authorization: "Bearer " + localStorage.getItem("token")})
  };

  loadAllPhysicianDataFromBackend() {
    this.http.get("http://localhost:8300/user/physicians", this.requestOptions).subscribe({
      next: (response) => {
        console.log("response", response);
        this.physicians = response;
      },
    });

  }

  appointmentTime = ["09:00 AM - 09:10 AM", "09:10 AM - 09:20 AM", "09:20 AM - 09:30 AM", "09:30 AM - 09:40 AM", "09:40 AM - 09:50 AM", "09:50 AM - 10:00 AM",
    "10:00 AM - 10:10 AM", "10:10 AM - 10:20 AM", "10:20 AM - 10:30 AM", "10:30 AM - 10:40 AM", "10:40 AM - 10:50 AM", "10:50 AM - 11:00 AM",
    "11:00 AM - 11:10 AM", "11:10 AM - 11:20 AM", "11:20 AM - 11:30 AM", "11:30 AM - 11:40 AM", "11:40 AM - 11:50 AM", "11:50 AM - 12:00 PM",
    "12:00 PM - 12:10 PM", "12:10 PM - 12:20 PM", "12:20 PM - 12:30 PM", "12:30 PM - 12:40 PM", "12:40 PM - 12:50 PM", "12:50 PM - 01:00 PM",
    "03:00 PM - 03:10 PM", "03:10 PM - 03:20 PM", "03:20 PM - 03:30 PM", "03:30 PM - 03:40 PM", "03:40 PM - 03:50 PM", "03:50 PM - 04:00 PM",
    "04:00 PM - 04:10 PM", "04:10 PM - 04:20 PM", "04:20 PM - 04:30 PM", "04:30 PM - 04:40 PM", "04:40 PM - 04:50 PM", "04:50 PM - 05:00 PM",
    "05:00 PM - 05:10 PM", "05:10 PM - 05:20 PM", "05:20 PM - 05:30 PM", "05:30 PM - 05:40 PM", "05:40 PM - 05:50 PM", "05:50 PM - 06:00 PM",
    "06:00 PM - 06:10 PM", "06:10 PM - 06:20 PM", "06:20 PM - 06:30 PM", "06:30 PM - 06:40 PM", "06:40 PM - 06:50 PM", "06:50 PM - 07:00 PM",
    "07:00 PM - 07:10 PM", "07:10 PM - 07:20 PM", "07:20 PM - 07:30 PM", "07:30 PM - 07:40 PM", "07:40 PM - 07:50 PM", "07:50 PM - 08:00 PM"];

  constructor(private formBuilder: FormBuilder,
    private appointmentService: AppointmentService,
    @Inject(MAT_DIALOG_DATA) public editData: any,
    private dialogRef: MatDialogRef<PatientAddAppointmentComponent>,
    private http: HttpClient) { }

  ngOnInit(): void {
    this.appointmentForm = this.formBuilder.group({
      title: ['', Validators.required],
      physicianId: ['', Validators.required],
      date: ['', Validators.required],
      timeSlot: ['', Validators.required],
      appointmentDescription: ['', Validators.required]
    })

    // console.log(this.editData);
    if (this.editData) {
      this.editBtn = "Update";
      this.appointmentForm.controls['title'].setValue(this.editData.title);
      this.appointmentForm.controls['physicianId'].setValue(this.editData.physicianId);
      this.appointmentForm.controls['date'].setValue(this.editData.date);
      this.appointmentForm.controls['timeSlot'].setValue(this.editData.startTime + " - " + this.editData.endTime);
      this.appointmentForm.controls['appointmentDescription'].setValue(this.editData.appointmentDescription);
    }

    this.loadAllPhysicianDataFromBackend();
  }

  saveAppointment() {
    let token: any = localStorage.getItem("token");

    // console.log(this.appointmentForm.value);
    const data = this.appointmentForm.value;
    //console.log(data);
    data.startTime = data.timeSlot.slice(0, 8);
    data.endTime = data.timeSlot.slice(11, 19);
    data.patientId = JSON.parse(atob(token.split(".")[1])).userId;
    console.log(data);

    delete data.timeSlot;
    // data.physicianId = "53";
    this.dialogRef.close('save');
    if (!this.editData) {
      if (this.appointmentForm.valid) {
        this.appointmentService.addAppointment(data)
          .subscribe({
            next: (res) => {
              alert("Appointment created successfully");
              this.appointmentForm.reset();
              this.dialogRef.close('Save');
            },
            error: () => {
              alert("Error while adding the product");
            }
          })
      }
    } else {
      this.updateAppointment(data);
    }
  }

  updateAppointment(data: any) {
    data.id = this.editData.id;
    // console.log(this.editData.id);
    console.log(data);
    this.appointmentService.updateAppointment(data)
      .subscribe({
        next: (res) => {
          alert("Product updated successfully");
          this.appointmentForm.reset();
          this.dialogRef.close('update');
        },
        error: () => {
          alert("Error while updating the product");
        }
      })
  }


}

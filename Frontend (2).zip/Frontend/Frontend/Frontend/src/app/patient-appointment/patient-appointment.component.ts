import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PatientAddAppointmentComponent } from './patient-add-appointment/patient-add-appointment.component';

@Component({
  selector: 'app-patient-appointment',
  templateUrl: './patient-appointment.component.html',
  styleUrls: ['./patient-appointment.component.css']
})
export class PatientAppointmentComponent implements OnInit {

  constructor(public dialog: MatDialog) {}

  ngOnInit(): void {

  }

  addAppointment() {

    const dialogRef = this.dialog.open(PatientAddAppointmentComponent);

  }

}

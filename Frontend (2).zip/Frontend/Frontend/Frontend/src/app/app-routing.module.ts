import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { AdminDashboardComponent } from './dashboard/admin-dashboard/admin-dashboard.component';
import { SideNavbarComponent } from './dashboard/side-navbar/side-navbar.component';
import { ViewAppointmentComponent } from './doctor-appointment/view-appointment/view-appointment.component';
import { UserLoginComponent } from './login/user-login/user-login.component';
import { PatientAddAppointmentComponent } from './patient-appointment/patient-add-appointment/patient-add-appointment.component';
import { PatientAppointmentComponent } from './patient-appointment/patient-appointment.component';
import { PatientViewAppointmentComponent } from './patient-appointment/patient-view-appointment/patient-view-appointment.component';
import { PatientDetailComponent } from './patient-detail/patient-detail.component';
import { HospitalUserRegistrationComponent } from './registration/hospital-user-registration/hospital-user-registration.component';
import { PatientRegistrationComponent } from './registration/patient-registration/patient-registration.component';

const routes: Routes = [
  { path: '', pathMatch: "full", redirectTo: "/login" },
   {path: 'login', component: UserLoginComponent},
   {path: 'register', component: PatientRegistrationComponent},
   {path: 'dashboard', component: SideNavbarComponent},
   {

    path: 'admin', component: SideNavbarComponent,

    children: [

      {

        path: 'dashboard', component: AdminDashboardComponent//, canActivate: [AuthGuard]

      },

       {

         path: 'user-registration', component: HospitalUserRegistrationComponent//, canActivate: [AuthGuard]

       },

      // {

      //   path: 'display-user/:roleId', component: DisplayHospitalUserComponent//, canActivate: [AuthGuard]

      // }

    ]

  },

  {
    path: 'patient', component: SideNavbarComponent,
    children: [
      {
        path: 'dashboard', component: PatientDetailComponent//, canActivate: [AuthGuard]
      },
      {
        path: 'view-appointments', component: PatientViewAppointmentComponent//, canActivate: [AuthGuard]
      },
      {
        path: 'add-appointments', component: PatientAppointmentComponent//, canActivate: [AuthGuard]
      }
    ]
  },

  {
    path: 'physician', component: SideNavbarComponent,
    children: [
      {
        path: 'view-appointments', component: ViewAppointmentComponent//, canActivate: [AuthGuard]
      },
      // {
      //   path: 'book-appointment', component: BookAppointmentComponent//, canActivate: [AuthGuard]
      // },
      // {
      //   path: 'details', component: ExtraDetailComponent//, canActivate: [AuthGuard]
      // }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

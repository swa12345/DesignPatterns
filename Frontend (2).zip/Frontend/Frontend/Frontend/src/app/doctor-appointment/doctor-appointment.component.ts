import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddAppointmentComponent } from './add-appointment/add-appointment.component';

@Component({
  selector: 'app-doctor-appointment',
  templateUrl: './doctor-appointment.component.html',
  styleUrls: ['./doctor-appointment.component.css']
})
export class DoctorAppointmentComponent implements OnInit {
  id: number = 1;
  title = 'appointment';

  constructor(public dialog: MatDialog) {}
  ngOnInit(): void {
  }

  addAppointment() {
    const dialogRef = this.dialog.open(AddAppointmentComponent);
  }

}

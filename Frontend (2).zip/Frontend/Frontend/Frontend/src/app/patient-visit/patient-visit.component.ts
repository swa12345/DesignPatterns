import { normalizePassiveListenerOptions } from '@angular/cdk/platform';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { PatientVisitServiceService } from '../patient-visit-service.service';
// import { JwtHelperService } from '@auth0/angular-jwt';

export class Diagnosis {
  constructor(
    public diagnosis_Is_Depricated: boolean,
    public diagnosis_Description: string,
    public diagnosis_Code: string,
  ) {
  }
}

export class Procedure {
  constructor(
    public procedure_Description: string,
    public prodcedure_Is_Depricated: boolean,
    public procedure_Id: string,
  ) {
  }
}

export class Medication {
  constructor(
    public drugId: string,
    public drugName: string,
    public drugGenericName: string,
    public drugBrandName: string,
    public drugForm: string,
  ) {
  }
}

export class PatientDetails {
  constructor(
    public patientId?: number,
    public title?: string,
    public age?: number,
    public gender?: string,
    public race?: string,
    public ethnicity?: string,
    public language?: string,
    public is_Allergic?: string,
    public allergy?: any,
    public emergencyConatctInfo?: string,
    public firstName?:string,
    public lastName?:string,
    public emailId?:string,
    public homeAddress?:string,
    public contactNumber?:number,
  ) {
  }
}


@Component({
  selector: 'app-patient-visit',
  templateUrl: './patient-visit.component.html',
  styleUrls: ['./patient-visit.component.css']
})

export class PatientVisitComponent implements OnInit {
  requestOptions = {                                                                                                                                                                                
    headers: new HttpHeaders({ Authorization: "Bearer " + localStorage.getItem("token")})
  };

  diagnosis: Diagnosis[];
  procedure: Procedure[];
  medication: Medication[];
  patientId: number;
  patientDetails = new PatientDetails();

  // helper = new JwtHelperService();
  title = 'CTHospital';

  data = {
    height: "",
    weight: "",
    bloodPressure: "",
    bodyTemperature: "",
    respirationRate: "",
    diagnosisValue: [],
    procedureValue: [],
    medicationValue: [],
    notes:"",
  }



  constructor(private snackBar:MatSnackBar,private activatedRoute: ActivatedRoute, private httpClient: HttpClient, private patientVisitService: PatientVisitServiceService) { }

  async ngOnInit() {
    this.getDiagnosis();
    this.getProcedure();
    this.getMedication();
    console.log('***********************');
    
    this.activatedRoute.params.subscribe(s => {
      // console.log(s["patientId"]);
      this.patientId = s["patientId"];
    });
    console.log('##########################');
    
    await this.getPatientDetails();

  }

  doSubmitForm() {
    console.log("Form has been submitted successfully");
    console.log(this.data.medicationValue);


    const procedureCode = [];
    this.data.procedureValue.forEach((pvalue) => {
      procedureCode.push(pvalue.procedure_Id);
    });
    console.log(procedureCode);

    const diagnosis = [];
    this.data.diagnosisValue.forEach((dvalue) => {
      diagnosis.push(dvalue.diagnosis_Code);
    });
    console.log(diagnosis);

    const medication = [];
    this.data.medicationValue.forEach((mvalue) => {

      medication.push(mvalue.drugId);
    });
    console.log(medication);
    let token : any = localStorage.getItem("token");

    const newData = {
      height: this.data.height,
      weight: this.data.weight,
      bloodPressure: this.data.bloodPressure,
      bodyTemparature: this.data.bodyTemperature,
      respirationRate: this.data.respirationRate,
      patientId: this.patientId,
      employeeId: JSON.parse(atob(token.split(".")[1])).userId,
      medication: medication,
      diagnosis: diagnosis,
      procedureCode: procedureCode,
      notes:this.data.notes

    }

    // return this.httpClient.post("http://localhost:8081/patientvisit/addPatientVisitDetails", this.requestOptions, newData);

    return this.httpClient.post("http://localhost:8081/patientvisit/addPatientVisitDetails", newData, this.requestOptions).subscribe(
      response => {
        // const decodedToken = this.helper.decodeToken(response.this.token);
        console.log(response);
      },
      error => {
        console.log(error);
      }
    )
  }

  btnClick(){
    
    this.snackBar.open("Data Submitted Successfully","Cancel")
  }

  getDiagnosis() {
    this.httpClient.get<any>('http://localhost:8081/patientvisit/getDiagnosisDetails', this.requestOptions).subscribe(
      response => {
        console.log(response);

        this.diagnosis = response;
      }
    )
  }

  getProcedure() {
    let token = localStorage.getItem('token');
    let headers = new Headers();

    headers.append('Authorization', 'Bearer '+token);

    let options = { headers: headers };
    this.httpClient.get<any>('http://localhost:8081/patientvisit/getProcedureDetails', this.requestOptions).subscribe(
      response => {
        console.log(response);

        this.procedure = response;
      }
    )
  }

  getMedication() {
    let token = localStorage.getItem('token');
    let headers = new Headers();

    headers.append('Authorization', 'Bearer '+token);

    let options = { headers: headers };
    this.httpClient.get<any>('http://localhost:8081/patientvisit/getMedicationDetails', this.requestOptions).subscribe(
      response => {
        console.log(response);

        this.medication = response;
      }
    )
  }

  async getPatientDetails() {
    let token = localStorage.getItem('token');
   
    let headers = new Headers();

    headers.append('Authorization', 'Bearer '+token);

    let options = { headers: headers };
    this.httpClient.get<any>(`http://localhost:9191/api/patient/${this.patientId}`, this.requestOptions).subscribe(
      response => {
        console.log(response);

        this.patientDetails = response;
      }
    )
  }
}
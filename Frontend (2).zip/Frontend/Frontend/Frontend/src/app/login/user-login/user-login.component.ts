import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup'
import { AuthenticationService } from 'src/app/authentication.service';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

    email: String = '';
    password: String = '';
    errorMessage: String = '';

  constructor(private http : HttpClient, private toast : NgToastService,
     private authService : AuthenticationService, private route : Router) { }

  ngOnInit(): void {
    //if (localStorage.getItem("token") != null) {

      // this.authService.logout().subscribe({

      //   next: (response) => {

      //     console.log(response);

         // localStorage.removeItem("token");

        //},

      //   error: (err) => console.error(err)

      // });

    //}
  }

  onSubmit(){
    // let headers = new Headers();
    // headers.append('Access-Control-Request-Headers', '*');
    // let options = { headers: headers };
    let requestObject = {
        emailId: this.email,
        password: this.password
    }

    this.authService.authenticateUser(requestObject)
    .subscribe(response => {
      localStorage.setItem("token", response);
      //this.toast.success({ detail: "Login success", summary: "", duration: 2000});
      let role = JSON.parse(atob(response.split(".")[1])).role;
      if(role === 'Admin'){
        this.route.navigate(['admin/dashboard']);
      }

      if(role === 'Physician'){
        this.route.navigate(['physician/dashboard']);
      }

      if(role === 'Patient'){
        this.route.navigate(['patient/dashboard']);
      }
    })
  }

  
  }



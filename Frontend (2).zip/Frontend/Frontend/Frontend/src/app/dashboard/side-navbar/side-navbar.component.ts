import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/authentication.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/internal/operators/map';
import { shareReplay } from 'rxjs/internal/operators/shareReplay';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-navbar',
  templateUrl: './side-navbar.component.html',
  styleUrls: ['./side-navbar.component.css']
})
export class SideNavbarComponent implements OnInit {

   roleName : String =  '';
   showReportIcon : boolean = false;

  constructor(private authService : AuthenticationService
    , private breakpointObserver: BreakpointObserver,
    private route : Router) { }

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  ngOnInit(): void {
    this.authService.userRole.subscribe(role => this.roleName = role);
    let token : any = localStorage.getItem("token");
    this.roleName = 'ROLE_' + JSON.parse(atob(token.split(".")[1])).role;
    // if (this.roleName === 'ROLE_Patient') {
    //   let patientEmailId = JSON.parse(atob(token.split(".")[1])).emailId;
    //   this.vitalDetailService.isVitalDetailsAvailable(patientEmailId).subscribe({
    //     next: (response) => {
    //       console.log(response);
    //       this.showReportIcon = true;
    //     },
    //     error: (err) => {
    //       console.log(err);
    //     }
    //   });
    // }
  }

  logout(){

   this.authService.logout().subscribe({
  
      next: (response) => {
        
        //localStorage.removeItem("token");
        
        //this.toast.success({ detail: "Logout successfully", summary: "", duration: 2000 });
  
      },
  
      error: (err) => {
  
        // this.toast.success({ detail: "Logout failed", summary: "Something went wrong" , duration: 2000, sticky: true });
     }
  
    })
  
    this.route.navigate(['login']);
  
  }

}
